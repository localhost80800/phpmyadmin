-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 01, 2023 at 11:23 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `seoski_turizam`
--

-- --------------------------------------------------------

--
-- Table structure for table `grad`
--

CREATE TABLE `grad` (
  `GradID` int(11) NOT NULL,
  `Grad` varchar(20) DEFAULT NULL,
  `PozivniBroj` int(11) DEFAULT NULL,
  `PostanskiBroj` int(11) DEFAULT NULL,
  `BrojStanovnika` decimal(10,0) DEFAULT NULL,
  `RegionID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `grad`
--

INSERT INTO `grad` (`GradID`, `Grad`, `PozivniBroj`, `PostanskiBroj`, `BrojStanovnika`, `RegionID`) VALUES
(1, 'Ruma', 22, 22400, '30', 1),
(2, 'Vrsac', 13, 26300, '29', 2),
(3, 'Novi Sad', 21, 21000, '243', 3),
(4, 'Kragujevac', 34, 34000, '179', 4),
(5, 'Pozarevac', 12, 12000, '60', 5),
(6, 'Tutin', 20, 36320, '31', 6),
(7, 'Uzice', 31, 31000, '52', 7),
(8, 'Kopaonik', 515, 44821, '20', 8),
(9, 'Bajina Basta', 31, 31250, '9', 9),
(10, 'Loznica', 15, 15300, '72', 10);

-- --------------------------------------------------------

--
-- Table structure for table `kategorija`
--

CREATE TABLE `kategorija` (
  `KategorijaID` int(11) NOT NULL,
  `Naziv` varchar(20) DEFAULT NULL,
  `Opis` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kategorija`
--

INSERT INTO `kategorija` (`KategorijaID`, `Naziv`, `Opis`) VALUES
(111, 'Losa', 'Losa kategorija'),
(222, 'Malo bolja', 'Malo bolja kategorij'),
(333, 'Solidan kategorija', 'Slodina kategorija '),
(444, 'Dobra kategorija', 'Dobra kategorija'),
(555, 'Vrlo dobra kategorij', 'Vrlo dobra i pristoj'),
(666, 'Odlicna kategorija', 'Odlicna kategorija '),
(777, 'Ekstra kategorija', 'Ekstra kategorija'),
(888, 'Vrhunska kategorija', 'Vrhunska kategorija'),
(999, 'Super kategorija', 'Super kategorija'),
(101010, 'Mega kategorija', 'Mega kategorija');

-- --------------------------------------------------------

--
-- Table structure for table `klijent`
--

CREATE TABLE `klijent` (
  `KlijentID` int(11) NOT NULL,
  `Ime` varchar(20) DEFAULT NULL,
  `Prezime` varchar(20) DEFAULT NULL,
  `Adresa` varchar(20) DEFAULT NULL,
  `GradID` int(11) DEFAULT NULL,
  `Telefon` int(11) DEFAULT NULL,
  `Email` varchar(20) DEFAULT NULL,
  `AktivanKlijent` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `klijent`
--

INSERT INTO `klijent` (`KlijentID`, `Ime`, `Prezime`, `Adresa`, `GradID`, `Telefon`, `Email`, `AktivanKlijent`) VALUES
(100, 'Andrija', 'Andric', 'Andrijevacka 22', 1, 6165761, 'andrija,andrija@gmai', 1),
(101, 'Bora', 'Boskic', 'Mihajla Pupina 9', 2, 64254812, 'bora.bora@gmail.com', 2),
(102, 'Petar', 'Peric', 'Nikola Tesla 12', 3, 6923421, 'petar.petar@gmail.co', 3),
(103, 'Goran', 'Gogic', 'Zivojina Misica 4', 4, 6256167, 'goran.goran@gmail.co', 4),
(104, 'Joca', 'Jocic', 'Kralja Petra I 54', 5, 6124215, 'joca.joca@gmail.com', 5),
(105, 'Djordje', 'Djinic', 'Nikola Tesla 64', 6, 64124567, 'djordje.djordje@gmai', 6),
(106, 'Ema', 'Estvic', 'Kralja Petra 102', 7, 65345643, 'ema.ema@gmail.com', 7),
(107, 'Zika', 'Zivanovic', 'Marsala Tita 2/10', 8, 66123453, 'zika.zika@gmail.com', 8),
(108, 'Zoran', 'Ivanovic', 'Kralja Milutina 124', 9, 62345346, 'zoran.zoran@gmail.co', 9),
(109, 'Ivica', 'Jovanovic', 'Crkvenoskola 2', 10, 60123564, 'ivica.ivica@gmail.co', 10);

-- --------------------------------------------------------

--
-- Table structure for table `kucica`
--

CREATE TABLE `kucica` (
  `KucicaID` int(11) NOT NULL,
  `KategorijaID` int(11) DEFAULT NULL,
  `Naziv` varchar(20) DEFAULT NULL,
  `BrojSoba` int(11) DEFAULT NULL,
  `Adresa` varchar(20) DEFAULT NULL,
  `SeloID` int(11) DEFAULT NULL,
  `SmerniceKakoStici` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kucica`
--

INSERT INTO `kucica` (`KucicaID`, `KategorijaID`, `Naziv`, `BrojSoba`, `Adresa`, `SeloID`, `SmerniceKakoStici`) VALUES
(1000, 111, 'Alpinska', 3, 'Ficina 10', 11, 'Pratiti kameni put p'),
(1001, 222, 'Vila Lux', 9, 'Radnicka 22', 22, 'Preci brdo i nastavi'),
(1002, 333, 'Apartmani AVA', 7, 'Oktobarske revolucij', 33, 'Pored reke pratiti p'),
(1003, 444, 'Kuca dobroh provoda', 4, 'Svetozara Markovica ', 44, 'Posle Kragujevca nas'),
(1004, 555, 'Apartman ELI', 3, 'Svetog Save 54', 55, 'Proci Pozarevac i pr'),
(1005, 666, 'Kuca ODLICNIH LJUDI', 12, 'Simonidina 56', 66, 'Na planini u sumici '),
(1006, 777, 'Apartmani EXTRA', 17, 'Pavlovacka 2', 77, 'Preko brda u dolini '),
(1007, 888, 'FIN aprtmani', 7, 'Srpskih sinova 112', 88, 'Na planini u podnozj'),
(1008, 999, 'SUPER LUX apartmani', 19, 'Cinkovi sinovi 12', 99, 'Na brdu na krsu na p'),
(1009, 101010, 'MEGA apartmani', 20, 'Dimitrija Tucovica', 1010, 'Uz putic pored reke');

-- --------------------------------------------------------

--
-- Table structure for table `region`
--

CREATE TABLE `region` (
  `RegionID` int(11) NOT NULL,
  `Naziv` varchar(20) DEFAULT NULL,
  `Opis` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `region`
--

INSERT INTO `region` (`RegionID`, `Naziv`, `Opis`) VALUES
(1, 'Srem', 'Ravan i lep predeo'),
(2, 'Banat', 'Ravan i divane prede'),
(3, 'Backa', 'Ravan i prelep prede'),
(4, 'Sumadija', 'Brdovit i sumovit pr'),
(5, 'Branicevo', 'Ravan i divan predeo'),
(6, 'Raski okrug ', 'Planinski i lep '),
(7, 'Zlatiborski', 'Planinski i cist'),
(8, 'Kopaonicki', 'Planinski i divan'),
(9, 'Tara', 'Planinski i sumovit'),
(10, 'Drinski', 'Recni i planinski');

-- --------------------------------------------------------

--
-- Table structure for table `rezervacija`
--

CREATE TABLE `rezervacija` (
  `Rbr` int(11) NOT NULL,
  `KucicaID` int(11) NOT NULL,
  `KlijentID` int(11) NOT NULL,
  `DatumRezervisanja` date DEFAULT NULL,
  `VremeRezervisanje` time DEFAULT NULL,
  `PocetakRezervacije` date DEFAULT NULL,
  `KrajRezervacije` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rezervacija`
--

INSERT INTO `rezervacija` (`Rbr`, `KucicaID`, `KlijentID`, `DatumRezervisanja`, `VremeRezervisanje`, `PocetakRezervacije`, `KrajRezervacije`) VALUES
(1, 1000, 100, '2022-02-09', '23:10:00', '2022-02-19', '2022-02-28'),
(2, 1001, 101, '2012-05-12', '09:15:00', '2012-05-19', '2012-06-01'),
(3, 1002, 102, '2015-09-11', '01:35:00', '2015-09-15', '2015-09-20'),
(4, 1003, 103, '2013-09-11', '12:35:00', '2013-09-15', '2013-09-20'),
(5, 1004, 104, '2019-03-02', '18:15:00', '2019-03-25', '2019-03-28'),
(6, 1005, 105, '2018-09-22', '20:00:00', '2018-09-25', '2018-09-29'),
(7, 1006, 106, '2020-04-01', '13:15:00', '2020-04-05', '2020-04-15'),
(8, 1007, 107, '2016-10-10', '15:35:00', '2016-10-15', '2016-10-20'),
(9, 1008, 108, '2019-08-08', '15:25:00', '2019-08-10', '2019-08-20'),
(10, 1009, 109, '2022-09-09', '17:50:00', '2022-09-15', '2022-09-20');

-- --------------------------------------------------------

--
-- Table structure for table `selo`
--

CREATE TABLE `selo` (
  `SeloID` int(11) NOT NULL,
  `Naziv` varchar(20) DEFAULT NULL,
  `GradID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `selo`
--

INSERT INTO `selo` (`SeloID`, `Naziv`, `GradID`) VALUES
(11, 'Klenak2', 1),
(22, 'Vrsacki Ritovi', 2),
(33, 'Kisac2', 3),
(44, 'Ilicevo', 4),
(55, 'Drmno2', 6),
(66, 'Velje Polje', 6),
(77, 'Volujac', 7),
(88, 'Brzece', 8),
(99, 'Jagostica', 9),
(1010, 'Trbusnica', 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `grad`
--
ALTER TABLE `grad`
  ADD PRIMARY KEY (`GradID`),
  ADD KEY `RegionID` (`RegionID`);

--
-- Indexes for table `kategorija`
--
ALTER TABLE `kategorija`
  ADD PRIMARY KEY (`KategorijaID`);

--
-- Indexes for table `klijent`
--
ALTER TABLE `klijent`
  ADD PRIMARY KEY (`KlijentID`),
  ADD KEY `GradID` (`GradID`);

--
-- Indexes for table `kucica`
--
ALTER TABLE `kucica`
  ADD PRIMARY KEY (`KucicaID`),
  ADD KEY `KategorijaID` (`KategorijaID`),
  ADD KEY `SeloID` (`SeloID`);

--
-- Indexes for table `region`
--
ALTER TABLE `region`
  ADD PRIMARY KEY (`RegionID`);

--
-- Indexes for table `rezervacija`
--
ALTER TABLE `rezervacija`
  ADD PRIMARY KEY (`Rbr`,`KucicaID`,`KlijentID`),
  ADD KEY `KucicaID` (`KucicaID`),
  ADD KEY `KlijentID` (`KlijentID`);

--
-- Indexes for table `selo`
--
ALTER TABLE `selo`
  ADD PRIMARY KEY (`SeloID`),
  ADD KEY `GradID` (`GradID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `grad`
--
ALTER TABLE `grad`
  ADD CONSTRAINT `grad_ibfk_1` FOREIGN KEY (`RegionID`) REFERENCES `region` (`RegionID`);

--
-- Constraints for table `klijent`
--
ALTER TABLE `klijent`
  ADD CONSTRAINT `klijent_ibfk_1` FOREIGN KEY (`GradID`) REFERENCES `grad` (`GradID`);

--
-- Constraints for table `kucica`
--
ALTER TABLE `kucica`
  ADD CONSTRAINT `kucica_ibfk_1` FOREIGN KEY (`KategorijaID`) REFERENCES `kategorija` (`KategorijaID`),
  ADD CONSTRAINT `kucica_ibfk_2` FOREIGN KEY (`SeloID`) REFERENCES `selo` (`SeloID`);

--
-- Constraints for table `rezervacija`
--
ALTER TABLE `rezervacija`
  ADD CONSTRAINT `rezervacija_ibfk_1` FOREIGN KEY (`KucicaID`) REFERENCES `kucica` (`KucicaID`),
  ADD CONSTRAINT `rezervacija_ibfk_2` FOREIGN KEY (`KlijentID`) REFERENCES `klijent` (`KlijentID`);

--
-- Constraints for table `selo`
--
ALTER TABLE `selo`
  ADD CONSTRAINT `selo_ibfk_1` FOREIGN KEY (`GradID`) REFERENCES `grad` (`GradID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
