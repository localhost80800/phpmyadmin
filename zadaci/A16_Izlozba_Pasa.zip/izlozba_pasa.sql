-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2023 at 06:01 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `izlozba_pasa`
--

-- --------------------------------------------------------

--
-- Table structure for table `boja`
--

CREATE TABLE `boja` (
  `BojaID` int(11) NOT NULL,
  `Boja` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `boja`
--

INSERT INTO `boja` (`BojaID`, `Boja`) VALUES
(16, 'Bela'),
(17, 'Crna'),
(18, 'Braon'),
(19, 'Krem'),
(20, 'Siva'),
(21, 'Tigrasta'),
(22, 'Saren'),
(23, 'Crno beli');

-- --------------------------------------------------------

--
-- Table structure for table `duzina_dlake`
--

CREATE TABLE `duzina_dlake` (
  `ddID` int(11) NOT NULL,
  `Duzina` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `duzina_dlake`
--

INSERT INTO `duzina_dlake` (`ddID`, `Duzina`) VALUES
(101, 'Dugodlaki'),
(202, 'Kratkodlaki');

-- --------------------------------------------------------

--
-- Table structure for table `izlozba`
--

CREATE TABLE `izlozba` (
  `izlozbaid` int(11) NOT NULL,
  `mesto` varchar(20) DEFAULT NULL,
  `datum` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `izlozba`
--

INSERT INTO `izlozba` (`izlozbaid`, `mesto`, `datum`) VALUES
(1, 'Cacak', '2022-06-05'),
(2, 'Beograd', '2022-06-30'),
(3, 'Mladenovac', '2022-06-21');

-- --------------------------------------------------------

--
-- Table structure for table `kategorija`
--

CREATE TABLE `kategorija` (
  `kategorijaid` int(11) NOT NULL,
  `naziv` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kategorija`
--

INSERT INTO `kategorija` (`kategorijaid`, `naziv`) VALUES
(1001, 'Mali'),
(1002, 'Malo veci'),
(1003, 'Srednji'),
(1004, 'Veci'),
(1005, 'Najveci');

-- --------------------------------------------------------

--
-- Table structure for table `pas`
--

CREATE TABLE `pas` (
  `PASID` int(11) NOT NULL,
  `ime` varchar(20) DEFAULT NULL,
  `tezina` int(11) DEFAULT NULL,
  `ddid` int(11) DEFAULT NULL,
  `bojaid` int(11) DEFAULT NULL,
  `rasaid` int(11) DEFAULT NULL,
  `ostenjen` date DEFAULT NULL,
  `vlasnikid` int(11) DEFAULT NULL,
  `polid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pas`
--

INSERT INTO `pas` (`PASID`, `ime`, `tezina`, `ddid`, `bojaid`, `rasaid`, `ostenjen`, `vlasnikid`, `polid`) VALUES
(1, 'Dingo', 30, 101, 16, 1, '2021-05-04', 56, 100),
(2, 'Baca', 40, 202, 22, 2, '2021-02-25', 55, 100),
(3, 'Ema', 30, 202, 18, 6, '2021-09-15', 57, 200),
(4, 'Sara', 10, 202, 19, 7, '2022-04-12', 58, 200),
(5, 'Zara', 50, 101, 18, 8, '2022-06-14', 59, 200),
(6, 'Aga', 60, 202, 16, 9, '2022-03-07', 60, 100),
(7, 'Cezar', 35, 101, 16, 13, '2022-04-04', 61, 100),
(8, 'Sima', 37, 202, 22, 3, '2022-03-14', 62, 100),
(9, 'Valkira', 40, 202, 18, 10, '2022-02-15', 63, 200),
(10, 'Lesi', 67, 101, 21, 12, '2022-02-15', 64, 100),
(11, 'Marta', 66, 202, 17, 4, '2021-12-14', 65, 200),
(12, 'Lea', 5, 202, 23, 5, '2021-11-16', 66, 200),
(13, 'Rea', 15, 202, 18, 14, '2022-04-04', 67, 200),
(14, 'Zuca', 55, 202, 23, 11, '2022-01-12', 68, 100),
(15, 'Fleka', 41, 202, 20, 6, '2022-03-08', 69, 200);

-- --------------------------------------------------------

--
-- Table structure for table `pol`
--

CREATE TABLE `pol` (
  `PolID` int(11) NOT NULL,
  `Pol` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pol`
--

INSERT INTO `pol` (`PolID`, `Pol`) VALUES
(100, 'Muski'),
(200, 'Zenski');

-- --------------------------------------------------------

--
-- Table structure for table `rasa`
--

CREATE TABLE `rasa` (
  `RasaID` int(11) NOT NULL,
  `Nazivrase` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rasa`
--

INSERT INTO `rasa` (`RasaID`, `Nazivrase`) VALUES
(1, 'Pitbull'),
(2, 'Buldog'),
(3, 'Terijer'),
(4, 'Labrador'),
(5, 'Civava'),
(6, 'Bokser'),
(7, 'Mops'),
(8, 'Vucijak'),
(9, 'Doga'),
(10, 'Doberman'),
(11, 'Dalmatinac'),
(12, 'Bernandinac'),
(13, 'Nemacki ovcar'),
(14, 'Pudlica'),
(15, 'Staford');

-- --------------------------------------------------------

--
-- Table structure for table `rezultat`
--

CREATE TABLE `rezultat` (
  `izlozbaid` int(11) DEFAULT NULL,
  `kategorijaid` int(11) DEFAULT NULL,
  `pasid` int(11) DEFAULT NULL,
  `rezultat` varchar(20) DEFAULT NULL,
  `napomena` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rezultat`
--

INSERT INTO `rezultat` (`izlozbaid`, `kategorijaid`, `pasid`, `rezultat`, `napomena`) VALUES
(1, 1005, 1, '1. mesto', 'Odlican'),
(1, 1003, 2, '2. mesto', ' Vrlo dobar'),
(1, 1003, 3, '3. mesto', 'Dobar'),
(1, 1001, 4, '4. mesto', 'Dovoljan'),
(1, 1002, 5, '5. mesto', 'Nedovoljan'),
(2, 1003, 6, '1. mesto', 'Odlican'),
(2, 1004, 7, '2. mesto', 'Vrlo dobar'),
(2, 1005, 8, '3. mesto', 'Dobar'),
(2, 1004, 9, '4. mesto', 'Dovoljan'),
(2, 1004, 10, '5. mesto', 'Nedovoljan'),
(3, 1005, 11, '1. mesto', 'Odlican'),
(3, 1005, 12, '2. mesto', 'Vrlo dobar'),
(3, 1004, 13, '3. mesto', 'Dobar'),
(3, 1004, 14, '4. mesto', 'Dovoljan'),
(3, 1004, 15, '5. mesto', 'Nedovoljan'),
(1, 1003, 2, 'NULL', 'NULL'),
(2, 1002, 3, 'NULL', 'NULL'),
(1, 1005, 2, 'NULL', 'NULL'),
(3, 1002, 2, 'NULL', 'NULL'),
(2, 1003, 6, 'NULL', 'NULL'),
(2, 1003, 10, 'NULL', 'NULL'),
(1, 1002, 2, 'NULL', 'NULL'),
(3, 1002, 1, 'NULL', 'NULL'),
(3, 1002, 1, 'NULL', 'NULL'),
(3, 1002, 7, 'NULL', 'NULL'),
(2, 1005, 10, 'NULL', 'NULL'),
(3, 1005, 10, 'NULL', 'NULL');

-- --------------------------------------------------------

--
-- Table structure for table `vlasnik`
--

CREATE TABLE `vlasnik` (
  `vlasnikid` int(11) NOT NULL,
  `ime` varchar(20) DEFAULT NULL,
  `prezime` varchar(20) DEFAULT NULL,
  `adresa` varchar(40) DEFAULT NULL,
  `jmbg` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vlasnik`
--

INSERT INTO `vlasnik` (`vlasnikid`, `ime`, `prezime`, `adresa`, `jmbg`) VALUES
(55, 'Milica', 'Jankovic', 'Mihajlna Pupina 3', 1278177281),
(56, 'Bojan', 'Kozomora', 'Rudnicka 3', 89563956),
(57, 'Milos', 'Lazarevic', 'Marka Jovica 89', 73860965),
(58, 'Jovan', 'Mijovic', 'Belosavce bb', 423984723),
(59, 'Nemanja', 'Markovic', 'Kusadak 3', 7589735),
(60, 'Nikola ', 'Mijailovic', 'Rabrovac 88', 78943585),
(61, 'Mihajlo ', 'Jovanovic', 'Vlaska 77', 58347938),
(62, 'Mateja', 'Milentijevic', 'Rabrovac 55', 5073853),
(63, 'Luka', 'Janosevic', 'Vrbica 69', 9435092),
(64, 'Aca', 'Stevankovic', 'Ripanj 99', 84209374),
(65, 'Tadej', 'Novicic', 'Vuka Karadzica 9', 348209834),
(66, 'Veljko', 'Pavlovic', 'Stojnik 9', 932840938),
(67, 'Anja', 'Gostencnik', 'Mihajla Milovanovica 17', 48293084),
(68, 'Andjelina', 'Andrejic', 'Mladenovac 8', 4782347),
(69, 'Andjela', 'Ristic', 'Hajduk Veljko 8', 930849028);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `boja`
--
ALTER TABLE `boja`
  ADD PRIMARY KEY (`BojaID`);

--
-- Indexes for table `duzina_dlake`
--
ALTER TABLE `duzina_dlake`
  ADD PRIMARY KEY (`ddID`);

--
-- Indexes for table `izlozba`
--
ALTER TABLE `izlozba`
  ADD PRIMARY KEY (`izlozbaid`);

--
-- Indexes for table `kategorija`
--
ALTER TABLE `kategorija`
  ADD PRIMARY KEY (`kategorijaid`);

--
-- Indexes for table `pas`
--
ALTER TABLE `pas`
  ADD PRIMARY KEY (`PASID`),
  ADD KEY `ddid` (`ddid`),
  ADD KEY `bojaid` (`bojaid`),
  ADD KEY `rasaid` (`rasaid`),
  ADD KEY `vlasnikid` (`vlasnikid`),
  ADD KEY `polid` (`polid`);

--
-- Indexes for table `pol`
--
ALTER TABLE `pol`
  ADD PRIMARY KEY (`PolID`);

--
-- Indexes for table `rasa`
--
ALTER TABLE `rasa`
  ADD PRIMARY KEY (`RasaID`);

--
-- Indexes for table `rezultat`
--
ALTER TABLE `rezultat`
  ADD KEY `izlozbaid` (`izlozbaid`),
  ADD KEY `kategorijaid` (`kategorijaid`),
  ADD KEY `pasid` (`pasid`);

--
-- Indexes for table `vlasnik`
--
ALTER TABLE `vlasnik`
  ADD PRIMARY KEY (`vlasnikid`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `pas`
--
ALTER TABLE `pas`
  ADD CONSTRAINT `pas_ibfk_1` FOREIGN KEY (`ddid`) REFERENCES `duzina_dlake` (`ddID`),
  ADD CONSTRAINT `pas_ibfk_2` FOREIGN KEY (`bojaid`) REFERENCES `boja` (`BojaID`),
  ADD CONSTRAINT `pas_ibfk_3` FOREIGN KEY (`rasaid`) REFERENCES `rasa` (`RasaID`),
  ADD CONSTRAINT `pas_ibfk_4` FOREIGN KEY (`vlasnikid`) REFERENCES `vlasnik` (`vlasnikid`),
  ADD CONSTRAINT `pas_ibfk_5` FOREIGN KEY (`polid`) REFERENCES `pol` (`PolID`);

--
-- Constraints for table `rezultat`
--
ALTER TABLE `rezultat`
  ADD CONSTRAINT `rezultat_ibfk_1` FOREIGN KEY (`izlozbaid`) REFERENCES `izlozba` (`izlozbaid`),
  ADD CONSTRAINT `rezultat_ibfk_2` FOREIGN KEY (`kategorijaid`) REFERENCES `kategorija` (`kategorijaid`),
  ADD CONSTRAINT `rezultat_ibfk_3` FOREIGN KEY (`pasid`) REFERENCES `pas` (`PASID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
