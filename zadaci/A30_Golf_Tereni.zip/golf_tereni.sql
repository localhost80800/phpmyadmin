-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2023 at 05:45 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `golf_tereni`
--

-- --------------------------------------------------------

--
-- Table structure for table `grad`
--

CREATE TABLE `grad` (
  `GradID` int(11) NOT NULL,
  `Grad` varchar(50) DEFAULT NULL,
  `PozivniBroj` decimal(50,0) DEFAULT NULL,
  `PostanskiBroj` decimal(50,0) DEFAULT NULL,
  `BrojStanovnika` decimal(50,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `grad`
--

INSERT INTO `grad` (`GradID`, `Grad`, `PozivniBroj`, `PostanskiBroj`, `BrojStanovnika`) VALUES
(12, 'mladenovac', '11', '11400', '500235'),
(123, 'beograd', '11', '35204', '150000'),
(234, 'cacak', '32', '32000', '82950'),
(345, 'gnjilane', '280', '60010', '50210'),
(456, 'jagodina', '35', '35000', '40210'),
(567, 'nis', '18', '18101', '75011'),
(678, 'novi sad', '21', '21000', '102665'),
(789, 'pirot', '10', '18300', '25124'),
(890, 'sombor', '25', '25105', '11257'),
(901, 'valjevo', '14', '14000', '64711');

-- --------------------------------------------------------

--
-- Table structure for table `igrac`
--

CREATE TABLE `igrac` (
  `IgracID` int(11) NOT NULL,
  `Ime` varchar(50) DEFAULT NULL,
  `Prezime` varchar(50) DEFAULT NULL,
  `Adresa` varchar(50) DEFAULT NULL,
  `GradID` int(11) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Telefon` decimal(50,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `igrac`
--

INSERT INTO `igrac` (`IgracID`, `Ime`, `Prezime`, `Adresa`, `GradID`, `Email`, `Telefon`) VALUES
(1333, 'goran', 'stankovic', 'nepoznato', 123, 'goranstankovicmankiyahoocom', '625275358'),
(1537, 'anja', 'gostencnik', 'teslina', 234, 'anjafginrmankigmailcom', '651388176'),
(3651, 'aleksandar', 'rankovic', 'dvajes peti maj', 12, 'rankogmailcom', '66424178'),
(5137, 'veljko', 'vojinovic', 'robna kuca', 890, 'vekipajsergmailiccom', '14752455'),
(5239, 'paja', 'pajser', 'pajserova ', 678, 'pajapakigmailcom', '631423699'),
(6411, 'andrija', 'andrejic', 'crkvena', 456, 'akiakilegmailcom', '64588124'),
(6424, 'djordje', 'taskovic', 'dvajes peti maj', 345, 'taletaskotakigmailcom', '62246752'),
(6532, 'nemanja', 'vulic', 'janka veselinovica', 12, 'nemanjadocentmakigmailcom', '603166423'),
(7112, 'andreja', 'zivotic', 'milutina milankovica', 789, 'agarixmankigmailcom', '613562621'),
(9137, 'stefan', 'ilic', 'ducinska', 678, 'stefanducinicamankilica', '81352164');

-- --------------------------------------------------------

--
-- Table structure for table `igraju`
--

CREATE TABLE `igraju` (
  `PartijaID` int(11) DEFAULT NULL,
  `IgracID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `igraju`
--

INSERT INTO `igraju` (`PartijaID`, `IgracID`) VALUES
(290850, 1537),
(300011, 9137),
(215641, 5239),
(531251, 6424),
(531118, 6532),
(300011, 5137),
(531251, 1333),
(351366, 6411),
(924113, 7112),
(544572, 3651);

-- --------------------------------------------------------

--
-- Table structure for table `partija`
--

CREATE TABLE `partija` (
  `PartijaID` int(11) NOT NULL,
  `TerenID` int(11) DEFAULT NULL,
  `Datum` date DEFAULT NULL,
  `VremePocetka` decimal(50,0) DEFAULT NULL,
  `VremeZavrsetka` decimal(50,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `partija`
--

INSERT INTO `partija` (`PartijaID`, `TerenID`, `Datum`, `VremePocetka`, `VremeZavrsetka`) VALUES
(215641, 61667, '2023-02-01', '6', '10'),
(290850, 18922, '2023-01-25', '15', '18'),
(300011, 12353, '2023-02-01', '19', '24'),
(351366, 51078, '2023-01-22', '18', '22'),
(515361, 53117, '2023-01-01', '15', '17'),
(531118, 62351, '2023-01-10', '19', '21'),
(531251, 51078, '2023-01-10', '12', '16'),
(544572, 61667, '2023-01-21', '17', '23'),
(924113, 86468, '2023-01-09', '12', '15'),
(982123, 35136, '2023-01-30', '9', '13');

-- --------------------------------------------------------

--
-- Table structure for table `rezultat`
--

CREATE TABLE `rezultat` (
  `RezultatID` int(11) NOT NULL,
  `IgracID` int(11) DEFAULT NULL,
  `PartijaID` int(11) DEFAULT NULL,
  `RupaID` int(11) DEFAULT NULL,
  `Skor` decimal(50,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rezultat`
--

INSERT INTO `rezultat` (`RezultatID`, `IgracID`, `PartijaID`, `RupaID`, `Skor`) VALUES
(48, 9137, 531251, 15, '11'),
(73, 6532, 531251, 70, '29'),
(74, 5239, 544572, 29, '23'),
(94, 5137, 982123, 123, '99'),
(127, 7112, 290850, 59, '14'),
(162, 1333, 531118, 91, '66'),
(166, 3651, 215641, 62, '67'),
(617, 1537, 351366, 58, '89'),
(644, 6411, 300011, 41, '90'),
(824, 6424, 515361, 27, '54');

-- --------------------------------------------------------

--
-- Table structure for table `rupa`
--

CREATE TABLE `rupa` (
  `RupaID` int(11) NOT NULL,
  `RupaRB` decimal(50,0) DEFAULT NULL,
  `TerenID` int(11) DEFAULT NULL,
  `Opis` varchar(50) DEFAULT NULL,
  `UdaljenostRupe` decimal(50,0) DEFAULT NULL,
  `UdaracaPoRupi` decimal(50,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rupa`
--

INSERT INTO `rupa` (`RupaID`, `RupaRB`, `TerenID`, `Opis`, `UdaljenostRupe`, `UdaracaPoRupi`) VALUES
(15, '12', 62351, 'ocajan skroz', '180', '3'),
(27, '6', 35136, 'nema zezanja', '900', '9'),
(29, '9', 62351, 'ocajan golf teren', '670', '7'),
(41, '11', 53111, 'ja nzm kako ovo da se predje', '850', '17'),
(58, '5', 53117, 'kao sto opis kaze kul je', '500', '7'),
(59, '2', 51078, 'bas je prosto', '400', '7'),
(62, '6', 95002, 'al nije tolko los', '150', '2'),
(70, '15', 18922, 'nigde nema ovo ludilo od terena', '540', '10'),
(91, '3', 61667, 'nemoguce', '300', '4'),
(123, '1', 86468, 'tolko lud da nije normalno', '1000', '12');

-- --------------------------------------------------------

--
-- Table structure for table `teren`
--

CREATE TABLE `teren` (
  `TerenID` int(11) NOT NULL,
  `Teren` varchar(50) DEFAULT NULL,
  `Adresa` decimal(50,0) DEFAULT NULL,
  `GradID` int(11) DEFAULT NULL,
  `KontaktTelefon` decimal(50,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teren`
--

INSERT INTO `teren` (`TerenID`, `Teren`, `Adresa`, `GradID`, `KontaktTelefon`) VALUES
(18922, 'original', '60', 789, '638176389'),
(35136, 'ozbiljan', '30', 234, '636587239'),
(51078, 'lak', '38', 567, '616420001'),
(53111, 'preterano tezak', '53', 12, '622551363'),
(53117, 'bas kul', '25', 901, '633177146'),
(61667, 'najtezi', '58', 12, '642460012'),
(62351, 'prelos', '75', 456, '681235412');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `grad`
--
ALTER TABLE `grad`
  ADD PRIMARY KEY (`GradID`);

--
-- Indexes for table `igrac`
--
ALTER TABLE `igrac`
  ADD PRIMARY KEY (`IgracID`),
  ADD KEY `GradID` (`GradID`);

--
-- Indexes for table `igraju`
--
ALTER TABLE `igraju`
  ADD KEY `PartijaID` (`PartijaID`),
  ADD KEY `IgracID` (`IgracID`);

--
-- Indexes for table `partija`
--
ALTER TABLE `partija`
  ADD PRIMARY KEY (`PartijaID`),
  ADD KEY `TerenID` (`TerenID`);

--
-- Indexes for table `rezultat`
--
ALTER TABLE `rezultat`
  ADD PRIMARY KEY (`RezultatID`),
  ADD KEY `PartijaID` (`PartijaID`),
  ADD KEY `IgracID` (`IgracID`),
  ADD KEY `RupaID` (`RupaID`);

--
-- Indexes for table `rupa`
--
ALTER TABLE `rupa`
  ADD PRIMARY KEY (`RupaID`),
  ADD KEY `TerenID` (`TerenID`);

--
-- Indexes for table `teren`
--
ALTER TABLE `teren`
  ADD KEY `GradID` (`GradID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `igrac`
--
ALTER TABLE `igrac`
  ADD CONSTRAINT `igrac_ibfk_1` FOREIGN KEY (`GradID`) REFERENCES `grad` (`GradID`);

--
-- Constraints for table `igraju`
--
ALTER TABLE `igraju`
  ADD CONSTRAINT `igraju_ibfk_1` FOREIGN KEY (`PartijaID`) REFERENCES `partija` (`PartijaID`),
  ADD CONSTRAINT `igraju_ibfk_2` FOREIGN KEY (`IgracID`) REFERENCES `igrac` (`IgracID`);

--
-- Constraints for table `partija`
--
ALTER TABLE `partija`
  ADD CONSTRAINT `partija_ibfk_1` FOREIGN KEY (`TerenID`) REFERENCES `teren` (`TerenID`);

--
-- Constraints for table `rezultat`
--
ALTER TABLE `rezultat`
  ADD CONSTRAINT `rezultat_ibfk_1` FOREIGN KEY (`PartijaID`) REFERENCES `partija` (`PartijaID`),
  ADD CONSTRAINT `rezultat_ibfk_2` FOREIGN KEY (`IgracID`) REFERENCES `igrac` (`IgracID`),
  ADD CONSTRAINT `rezultat_ibfk_3` FOREIGN KEY (`RupaID`) REFERENCES `rupa` (`RupaID`);

--
-- Constraints for table `rupa`
--
ALTER TABLE `rupa`
  ADD CONSTRAINT `rupa_ibfk_1` FOREIGN KEY (`TerenID`) REFERENCES `teren` (`TerenID`);

--
-- Constraints for table `teren`
--
ALTER TABLE `teren`
  ADD CONSTRAINT `teren_ibfk_1` FOREIGN KEY (`GradID`) REFERENCES `grad` (`GradID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
