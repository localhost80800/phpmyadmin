﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySqlConnector;

namespace A30_Golf_tereni
{
    public partial class Form2 : Form
    {
        MySqlConnection konekcija = new MySqlConnection();
        MySqlCommand komanda = new MySqlCommand();
        DataTable tabela = new DataTable();
        MySqlDataAdapter adapter = new MySqlDataAdapter();
        DataSet podaci = new DataSet();
        MySqlDataReader rezultat;
        string upit;
        string temp = "server=localhost;user id=root;password=asd123;database=golf_tereni";
        public Form2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataTable tabela2 = new DataTable();
            konekcija.ConnectionString = temp;
            konekcija.Open();
            komanda.Connection = konekcija;

            upit = "SELECT partija.PartijaID,teren.Teren,partija.Datum,((partija.VremeZavrsetka-partija.VremePocetka)*60) as Trajanje From partija INNER JOIN teren on partija.TerenID=teren.TerenID WHERE partija.VremeZavrsetka-partija.VremePocetka>=" + comboBox1.Text+ " and partija.VremeZavrsetka-partija.VremePocetka<=" + comboBox2.Text+" order by Trajanje desc";
            MessageBox.Show(upit);


            komanda.CommandText = upit;
            rezultat = komanda.ExecuteReader();

            chart1.ChartAreas[0].AxisX.Title = "Teren";
            chart1.ChartAreas[0].AxisY.Title = "Trajanje u minutima";

            tabela2.Load(rezultat);

            dataGridView1.DataSource = tabela2;

            chart1.DataSource = tabela2;
            chart1.Series["Series1"].XValueMember = "Teren";
            chart1.Series["Series1"].YValueMembers = "Trajanje";
            rezultat.Close();
            konekcija.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
