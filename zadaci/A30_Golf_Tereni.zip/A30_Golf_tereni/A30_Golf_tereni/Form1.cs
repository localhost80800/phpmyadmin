﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySqlConnector;

namespace A30_Golf_tereni
{
    public partial class Form1 : Form
    {
        MySqlConnection konekcija = new MySqlConnection();
        MySqlCommand komanda = new MySqlCommand();
        DataTable tabela = new DataTable();
        MySqlDataAdapter adapter = new MySqlDataAdapter();
        DataSet podaci = new DataSet();
        MySqlDataReader rezultat;
        string upit;
        string temp = "server=localhost; user id=root; password=asd123; database=golf_tereni";
        string razmak = "                    ";
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

            if (listBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Prvom odaberite neki teren");
            }
            else {
                DialogResult dialog1 = MessageBox.Show("Da li ste sigurni da zelite obrisati izabrani teren?", "Brisanje terena", MessageBoxButtons.YesNo);
                if (dialog1 == DialogResult.Yes)
            {
                konekcija.ConnectionString = temp;
                konekcija.Open();
                komanda.Connection = konekcija;
                upit = "DELETE FROM Teren where TerenID=" + comboBox1.Text;
                komanda.CommandText = upit;
                rezultat = komanda.ExecuteReader();
                tabela.Reset();
                tabela.Load(rezultat);
                rezultat.Close();
                konekcija.Close();

                load();
                comboBox1.Text = "";
                comboBox2.Text = "";
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
            }
            else { }
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            load();
        }
        private void load() {
            konekcija.ConnectionString = temp;
            konekcija.Open();
            komanda.Connection = konekcija;
            upit = "SELECT grad from grad";
            komanda.CommandText = upit;
            rezultat = komanda.ExecuteReader();
            tabela.Reset();
            tabela.Load(rezultat);
            listBox1.Items.Clear();
            for (int i = 0; i < tabela.Rows.Count; i++)
            {
                string s1 = tabela.Rows[i].ItemArray[0].ToString();
                if (comboBox2.Items.Contains(s1)) { } else comboBox2.Items.Add(s1);
            }
            rezultat.Close();
            konekcija.Close();

            konekcija.ConnectionString = temp;
            konekcija.Open();
            komanda.Connection = konekcija;
            upit = "SELECT teren.TerenID,teren.Teren,teren.Adresa,teren.KontaktTelefon,grad.Grad from teren INNER JOIN grad on teren.GradID=grad.GradID";
            komanda.CommandText = upit;
            rezultat = komanda.ExecuteReader();
            tabela.Reset();
            tabela.Load(rezultat);
            listBox1.Items.Clear();
            for (int i = 0; i < tabela.Rows.Count; i++)
            {
                string s1 = (tabela.Rows[i].ItemArray[0].ToString() + razmak).Substring(0, 8);
                string s2 = (tabela.Rows[i].ItemArray[1].ToString() + razmak+razmak+razmak).Substring(0, 40);
                string s3 = (tabela.Rows[i].ItemArray[2].ToString() + razmak+razmak).Substring(0, 25);
                string s4 = (tabela.Rows[i].ItemArray[3].ToString() + razmak).Substring(0, 25);
                string s5 = (tabela.Rows[i].ItemArray[4].ToString() + razmak).Substring(0, 20);

                string ceo = s1 + s2 + s3 + s4 + s5;
                listBox1.Items.Add(ceo);
            }
            rezultat.Close();
            konekcija.Close();



        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int k = listBox1.SelectedIndex;
            comboBox1.Text = tabela.Rows[k].ItemArray[0].ToString();
            textBox1.Text = tabela.Rows[k].ItemArray[1].ToString();
            textBox2.Text = tabela.Rows[k].ItemArray[2].ToString();
            comboBox2.Text = tabela.Rows[k].ItemArray[4].ToString();
            textBox3.Text = tabela.Rows[k].ItemArray[3].ToString();
        }

        private void comboBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) {
                if (comboBox1.Text != "") { 
            konekcija.ConnectionString = temp;
            konekcija.Open();
            komanda.Connection = konekcija;
            upit = "SELECT teren.TerenID,teren.Teren,teren.Adresa,teren.KontaktTelefon,grad.Grad from teren INNER JOIN grad on teren.GradID=grad.GradID where teren.terenid="+comboBox1.Text;
            komanda.CommandText = upit;
            rezultat = komanda.ExecuteReader();
            tabela.Reset();
            tabela.Load(rezultat);
            int k = tabela.Rows.Count;
            if (tabela.Rows.Count > 0)
            {
                listBox1.Items.Clear();
                for (int i = 0; i < tabela.Rows.Count; i++)
                {
                    string s1 = (tabela.Rows[i].ItemArray[0].ToString() + razmak).Substring(0, 8);
                    string s2 = (tabela.Rows[i].ItemArray[1].ToString() + razmak + razmak + razmak).Substring(0, 40);
                    string s3 = (tabela.Rows[i].ItemArray[2].ToString() + razmak + razmak).Substring(0, 25);
                    string s4 = (tabela.Rows[i].ItemArray[3].ToString() + razmak).Substring(0, 25);
                    string s5 = (tabela.Rows[i].ItemArray[4].ToString() + razmak).Substring(0, 20);

                    string ceo = s1 + s2 + s3 + s4 + s5;
                    listBox1.Items.Add(ceo);
                }
                rezultat.Close();
                konekcija.Close();
            }
            else {
                rezultat.Close();
                konekcija.Close();
                MessageBox.Show("Sifra ne postoji!");
                        load();
            }
            }
            }
        }
    }
}
