-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2023 at 10:29 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `evidencija_radnika`
--

-- --------------------------------------------------------

--
-- Table structure for table `angazman`
--

CREATE TABLE `angazman` (
  `radnikid` int(11) NOT NULL,
  `projekatid` int(11) NOT NULL,
  `datumangazovanja` int(11) NOT NULL,
  `brojsati` int(20) DEFAULT NULL,
  `opisposla` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `angazman`
--

INSERT INTO `angazman` (`radnikid`, `projekatid`, `datumangazovanja`, `brojsati`, `opisposla`) VALUES
(776, 2468, 2000, 27, 'opis999'),
(512, 1234, 2001, 45, 'opis111'),
(849, 7890, 2004, 219, 'opis777'),
(913, 4567, 2005, 179, 'opis444'),
(100, 5678, 2006, 19, 'opis555'),
(578, 6251, 2009, 81, 'opis100'),
(846, 3456, 2011, 89, 'opis333'),
(620, 2345, 2015, 105, 'opis222'),
(345, 1357, 2016, 103, 'opis888'),
(990, 6789, 2018, 300, 'opis666');

-- --------------------------------------------------------

--
-- Table structure for table `istorija_rm_radnika`
--

CREATE TABLE `istorija_rm_radnika` (
  `radnikid` int(11) NOT NULL,
  `radnomestoid` int(11) NOT NULL,
  `datumpocetka` int(11) NOT NULL,
  `datumzavrsetka` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `istorija_rm_radnika`
--

INSERT INTO `istorija_rm_radnika` (`radnikid`, `radnomestoid`, `datumpocetka`, `datumzavrsetka`) VALUES
(100, 77, 2006, '2007-01-20'),
(345, 55, 2005, '2006-05-21'),
(512, 66, 2004, '2015-05-21'),
(578, 44, 2004, '2006-02-25'),
(620, 33, 2007, '2009-02-12'),
(776, 22, 2021, '2022-01-23'),
(846, 10, 2000, '2004-12-06'),
(849, 11, 2006, '2010-12-20'),
(913, 99, 2018, '2021-01-20'),
(990, 88, 2018, '2020-02-21');

-- --------------------------------------------------------

--
-- Table structure for table `kvalifikacija`
--

CREATE TABLE `kvalifikacija` (
  `kvalifikacijaid` int(11) NOT NULL,
  `naziv` varchar(20) DEFAULT NULL,
  `koeficijent` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kvalifikacija`
--

INSERT INTO `kvalifikacija` (`kvalifikacijaid`, `naziv`, `koeficijent`) VALUES
(1010, 'pekar', 74),
(1111, 'postar', 25),
(2222, 'kuvar', 84),
(3333, 'pekar', 52),
(4444, 'vozac', 66),
(5555, 'mesar', 89),
(6666, 'konobar', 98),
(7777, 'kasir', 65),
(8888, 'biciklista', 11),
(9999, 'maneken', 61);

-- --------------------------------------------------------

--
-- Table structure for table `projekat`
--

CREATE TABLE `projekat` (
  `projekatid` int(11) NOT NULL,
  `naziv` varchar(20) DEFAULT NULL,
  `datumpocetka` date DEFAULT NULL,
  `budzet` decimal(20,0) DEFAULT NULL,
  `projekatzavrsen` varchar(20) DEFAULT NULL,
  `opis` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `projekat`
--

INSERT INTO `projekat` (`projekatid`, `naziv`, `datumpocetka`, `budzet`, `projekatzavrsen`, `opis`) VALUES
(1357, 'projekat8', '2000-02-21', '62000', 'nije', 'opis8'),
(2345, 'projekat2', '2003-06-02', '25000', 'jeste', 'opis2'),
(2468, 'projekat9', '2006-02-21', '20500', 'jeste', 'opis9'),
(3456, 'projekat3', '2003-01-25', '50000', 'jeste', 'opis3'),
(4567, 'projekat4', '2007-08-12', '80000', 'jeste', 'opis4'),
(5678, 'projekat5', '2015-12-12', '45000', 'nije', 'opis5'),
(6789, 'projekat6', '2001-05-06', '50500', 'jeste', 'opis6'),
(7890, 'projekat7', '2011-01-15', '25600', 'nije', 'opis7');

-- --------------------------------------------------------

--
-- Table structure for table `radnik`
--

CREATE TABLE `radnik` (
  `radnikid` int(11) NOT NULL,
  `ime` varchar(20) DEFAULT NULL,
  `prezime` varchar(20) DEFAULT NULL,
  `datumrodjenja` date DEFAULT NULL,
  `datumzaposljenja` date DEFAULT NULL,
  `kvalifikacijaid` int(20) DEFAULT NULL,
  `telefon` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `radnik`
--

INSERT INTO `radnik` (`radnikid`, `ime`, `prezime`, `datumrodjenja`, `datumzaposljenja`, `kvalifikacijaid`, `telefon`) VALUES
(100, 'Maja', 'Lazarevic', '1989-12-01', '2006-08-27', 1111, 633366993),
(345, 'Petar', 'Colic', '1989-06-14', '2006-11-17', 2222, 648275266),
(512, 'Ana', 'Zivanovic', '2000-02-24', '2020-07-01', 3333, 603166444),
(578, 'Slobodan', 'Sabic', '2000-01-25', '2022-04-01', 4444, 606290178),
(620, 'Goran', 'Remsijevic', '1992-01-24', '2019-08-02', 5555, 615237357),
(776, 'Sasa', 'Kovacevic', '1976-12-05', '1999-12-26', 6666, 631662371),
(846, 'Jole', 'Zivkovic', '2001-01-28', '2022-03-21', 7777, 605112526),
(849, 'Milan', 'Jeremic', '1960-05-26', '1984-02-24', 8888, 601228379),
(913, 'Kole', 'Kuzmanovic', '1999-06-03', '2021-02-05', 9999, 607465128),
(990, 'Marko', 'Culafic', '1981-08-12', '2000-01-22', 1010, 626266344);

-- --------------------------------------------------------

--
-- Table structure for table `radno_mesto`
--

CREATE TABLE `radno_mesto` (
  `radnomestoid` int(11) NOT NULL,
  `naziv` varchar(20) DEFAULT NULL,
  `opis` varchar(20) DEFAULT NULL,
  `pocetnaplata` decimal(20,0) DEFAULT NULL,
  `najvisaplata` decimal(20,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `radno_mesto`
--

INSERT INTO `radno_mesto` (`radnomestoid`, `naziv`, `opis`, `pocetnaplata`, `najvisaplata`) VALUES
(10, 'gnjilane', 'opis10', '10000', '50000'),
(11, 'mladenovac', 'opis11', '20000', '50000'),
(22, 'rabrovac', 'opis22', '34000', '42000'),
(33, 'beograd', 'opis33', '51000', '62000'),
(44, 'vrsac', 'opis44', '15000', '20000'),
(55, 'obrenovac', 'opis55', '56000', '80000'),
(66, 'arandjelovac', 'opis66', '51000', '70000'),
(77, 'kragujevac', 'opis77', '41900', '53400'),
(88, 'krusevac', 'opis88', '90000', '120000'),
(99, 'jagnjilo', 'opis99', '53000', '76000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `angazman`
--
ALTER TABLE `angazman`
  ADD PRIMARY KEY (`datumangazovanja`),
  ADD KEY `radnikid` (`radnikid`);

--
-- Indexes for table `istorija_rm_radnika`
--
ALTER TABLE `istorija_rm_radnika`
  ADD PRIMARY KEY (`radnikid`,`radnomestoid`,`datumpocetka`),
  ADD KEY `radnomestoid` (`radnomestoid`);

--
-- Indexes for table `kvalifikacija`
--
ALTER TABLE `kvalifikacija`
  ADD PRIMARY KEY (`kvalifikacijaid`);

--
-- Indexes for table `radnik`
--
ALTER TABLE `radnik`
  ADD PRIMARY KEY (`radnikid`),
  ADD KEY `kvalifikacijaid` (`kvalifikacijaid`);

--
-- Indexes for table `radno_mesto`
--
ALTER TABLE `radno_mesto`
  ADD PRIMARY KEY (`radnomestoid`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `angazman`
--
ALTER TABLE `angazman`
  ADD CONSTRAINT `angazman_ibfk_1` FOREIGN KEY (`radnikid`) REFERENCES `radnik` (`radnikid`),
  ADD CONSTRAINT `angazman_ibfk_2` FOREIGN KEY (`projekatid`) REFERENCES `projekat` (`projekatid`);

--
-- Constraints for table `istorija_rm_radnika`
--
ALTER TABLE `istorija_rm_radnika`
  ADD CONSTRAINT `istorija_rm_radnika_ibfk_1` FOREIGN KEY (`radnikid`) REFERENCES `radnik` (`radnikid`),
  ADD CONSTRAINT `istorija_rm_radnika_ibfk_2` FOREIGN KEY (`radnomestoid`) REFERENCES `radno_mesto` (`radnomestoid`),
  ADD CONSTRAINT `istorija_rm_radnika_ibfk_3` FOREIGN KEY (`radnikid`) REFERENCES `radnik` (`radnikid`);

--
-- Constraints for table `radnik`
--
ALTER TABLE `radnik`
  ADD CONSTRAINT `radnik_ibfk_1` FOREIGN KEY (`kvalifikacijaid`) REFERENCES `kvalifikacija` (`kvalifikacijaid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
