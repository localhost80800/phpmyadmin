-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2023 at 04:25 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `produzeni_boravak`
--

-- --------------------------------------------------------

--
-- Table structure for table `aktivnosti`
--

CREATE TABLE `aktivnosti` (
  `aktivnostid` int(11) NOT NULL,
  `nazivaktivnosti` varchar(20) DEFAULT NULL,
  `dan` varchar(20) DEFAULT NULL,
  `pocetak` varchar(20) DEFAULT NULL,
  `zavrsetak` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `aktivnosti`
--

INSERT INTO `aktivnosti` (`aktivnostid`, `nazivaktivnosti`, `dan`, `pocetak`, `zavrsetak`) VALUES
(15, 'crtanje', 'ponedeljak', '12:00', '13:00'),
(23, 'Pisanje', 'utorak', '14:00', '17:00'),
(24, 'francuski', 'ponedeljak', '14:00', '15:00'),
(30, 'ples', 'utorak', '13:00', '14:00'),
(35, 'folklor', 'sreda', '12:45', '13:55'),
(44, 'recital', 'cetvrtak', '12:00', '13:00'),
(45, 'Gledanje crtaca', 'sreda', '11:00', '12:00'),
(48, 'gluma', 'petak', '15:00', '17:00'),
(49, 'nemacki', 'utorak', '12:00', '13:00'),
(56, 'trcanje', 'petak', '12:00', '12:30'),
(62, 'igranje', 'ponedeljak', '12:00', '13:00'),
(65, 'plivanje', 'sreda', '09:00', '10:00'),
(67, 'cetvrtak', 'petak', '10:30', '11:00'),
(89, 'cetvrtak', 'sreda', '12:00', '14:00'),
(98, 'bioskop', 'petak', '11:00', '15:00'),
(99, 'Ruski rulet', 'utorak', '12:00', '13:00'),
(100, 'cupkanje', 'ponedeljak', '12:25', '12:35');

-- --------------------------------------------------------

--
-- Table structure for table `dete`
--

CREATE TABLE `dete` (
  `deteid` int(11) NOT NULL,
  `polid` int(11) DEFAULT NULL,
  `ime` varchar(20) DEFAULT NULL,
  `prezime` varchar(20) DEFAULT NULL,
  `datumrodjenja` date DEFAULT NULL,
  `belekse` varchar(20) DEFAULT NULL,
  `roditeljid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dete`
--

INSERT INTO `dete` (`deteid`, `polid`, `ime`, `prezime`, `datumrodjenja`, `belekse`, `roditeljid`) VALUES
(201, 92, 'Marko', 'Jovanovic', '2021-09-13', 'beleska1', 10),
(202, 86, 'Ivan', 'Spasojevic', '2021-08-09', 'beleksa2', 70),
(203, 98, 'Zivojin', 'Maksimovic', '2021-11-08', 'beleska3', 60),
(204, 88, 'Kosta', 'Rokvic', '2020-06-03', 'beleska4', 20),
(205, 90, 'Milan', 'Ivanovic', '2021-05-10', NULL, 50),
(206, 96, 'Milos', 'Ristic', '2020-02-13', 'beleksa6', 30),
(207, 94, 'Dejan', 'Mitrovic', '2021-05-31', 'beleska 7', 90),
(208, 97, 'Iva', 'Kristovic', '2019-05-21', 'beleska8', 80),
(209, 95, 'Jovana', 'Maksimovic', '2022-03-02', 'beleska9', 110),
(210, 93, 'Ivana', 'Atanskovic', '2020-12-09', 'beleska10', 150),
(211, 85, 'Antonina', 'Rakic', '2022-06-07', 'belska11', 130),
(212, 91, 'Dora', 'Milovanovic', '2022-03-09', 'beleska12', 140),
(213, 89, 'Mia', 'Pavlovic', '2021-06-14', 'belska13', 100),
(214, 87, 'aleksandra', 'Milovanovic', '2021-12-22', 'beleska14', 120),
(215, 99, 'Dorotea', 'jovanovic', '2021-03-09', 'beleska15', 40);

-- --------------------------------------------------------

--
-- Table structure for table `pol`
--

CREATE TABLE `pol` (
  `polid` int(11) NOT NULL,
  `pol` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pol`
--

INSERT INTO `pol` (`polid`, `pol`) VALUES
(85, 'zensko'),
(86, 'musko'),
(87, 'zensko'),
(88, 'musko'),
(89, 'zensko'),
(90, 'musko'),
(91, 'zensko'),
(92, 'musko'),
(93, 'zensko'),
(94, 'musko'),
(95, 'zensko'),
(96, 'musko'),
(97, 'zensko'),
(98, 'musko'),
(99, 'zensko');

-- --------------------------------------------------------

--
-- Table structure for table `registar_aktivnosti`
--

CREATE TABLE `registar_aktivnosti` (
  `aktivnostid` int(11) DEFAULT NULL,
  `deteid` int(11) DEFAULT NULL,
  `datumid` date NOT NULL,
  `prisustvo` varchar(20) DEFAULT NULL,
  `belska` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registar_aktivnosti`
--

INSERT INTO `registar_aktivnosti` (`aktivnostid`, `deteid`, `datumid`, `prisustvo`, `belska`) VALUES
(23, 202, '2021-04-11', 'ne', 'beleska2'),
(15, 201, '2021-05-11', 'da', 'beleska1'),
(98, 215, '2022-02-01', 'ne', 'beleska15'),
(89, 214, '2022-02-02', 'da', 'beleska14'),
(67, 213, '2022-02-03', 'ne', 'beleska13'),
(65, 212, '2022-02-04', 'ne', 'beleska12'),
(62, 211, '2022-02-05', 'da', 'beleska11'),
(56, 210, '2022-02-06', 'ne', 'beleska10'),
(49, 209, '2022-02-07', 'ne', 'beleska9'),
(48, 208, '2022-02-08', 'da', 'beleska8'),
(45, 207, '2022-02-09', 'ne', 'beleska7'),
(44, 206, '2022-02-10', 'da', 'beleska6'),
(35, 205, '2022-02-11', 'da', 'beleska5'),
(30, 204, '2022-02-12', 'ne', 'beleska4'),
(24, 203, '2022-03-11', 'da', 'beleska3');

-- --------------------------------------------------------

--
-- Table structure for table `roditelj`
--

CREATE TABLE `roditelj` (
  `roditeljid` int(11) NOT NULL,
  `svojstvoid` int(11) DEFAULT NULL,
  `ime` varchar(20) DEFAULT NULL,
  `prezime` varchar(20) DEFAULT NULL,
  `adresa` varchar(20) DEFAULT NULL,
  `fiksnitelefon` int(11) DEFAULT NULL,
  `mobilnitelefon` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `roditelj`
--

INSERT INTO `roditelj` (`roditeljid`, `svojstvoid`, `ime`, `prezime`, `adresa`, `fiksnitelefon`, `mobilnitelefon`) VALUES
(10, 1, 'Ana', 'Jovanovic', 'Kralja Aleksandra', 1126587, 6124578),
(20, 2, 'Goran', 'Rokvic', 'Milutina Milenkovica', 11654987, 6258975),
(30, 3, 'Jelena', 'Ristic', 'Kralja Perta Prvog', 11853647, 616278204),
(40, 4, 'Zeljko', 'Jovanovic', 'Dedinjska', 1147852, 6239745),
(50, 5, 'Ivan', 'Ivanovic', 'Vuka Karadzica', 1169875, 658996778),
(60, 6, 'Anita', 'Maksimovic', 'Nikola Pasic', 1128596, 616278256),
(70, 7, 'Ana', 'Spasojevic', 'Kraljice Marije', 11237895, 61624598),
(80, 8, 'Kristina', 'Kristovic', 'Kosmajska', 1124986, 61627459),
(90, 9, 'Jovan', 'Mitrovic', 'Crvekna', 1124965, 6235987),
(100, 10, 'Veljko', 'Pavlovic', 'Sumadijska ', 11234985, 65899645),
(110, 11, 'Marija', 'Maksimovic', 'Karadjordjeva', 119857, 6459887),
(120, 12, 'Zaklina', 'Milovanovic', 'Hajduk Veljkova', 1158963, 6498752),
(130, 13, 'Milutin', 'Rakic', 'Kosmajski put', 114598, 6582396),
(140, 14, 'Stefan', 'Milovanovic', 'Danica Markovic', 1126985, 61625987),
(150, 15, 'Mia', 'Atanaskovic', 'Gimnazijska', 11456287, 61628549);

-- --------------------------------------------------------

--
-- Table structure for table `svojstvo_roditelja`
--

CREATE TABLE `svojstvo_roditelja` (
  `svojstvoid` int(11) NOT NULL,
  `svojstvo` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `svojstvo_roditelja`
--

INSERT INTO `svojstvo_roditelja` (`svojstvoid`, `svojstvo`) VALUES
(1, 'svojstvo1'),
(2, 'svojstvo2'),
(3, 'svojstvo3'),
(4, 'svojstvo4'),
(5, 'svojstvo5'),
(6, 'svojstvo6'),
(7, 'svojstvo7'),
(8, 'svojstvo8'),
(9, 'svojstvo9'),
(10, 'svojstvo10'),
(11, 'svojstvo11'),
(12, 'svojstvo12'),
(13, 'svojstvo13'),
(14, 'svojstvo14'),
(15, 'svojsjtvo15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aktivnosti`
--
ALTER TABLE `aktivnosti`
  ADD PRIMARY KEY (`aktivnostid`);

--
-- Indexes for table `dete`
--
ALTER TABLE `dete`
  ADD PRIMARY KEY (`deteid`),
  ADD KEY `polid` (`polid`),
  ADD KEY `roditeljid` (`roditeljid`);

--
-- Indexes for table `pol`
--
ALTER TABLE `pol`
  ADD PRIMARY KEY (`polid`);

--
-- Indexes for table `registar_aktivnosti`
--
ALTER TABLE `registar_aktivnosti`
  ADD PRIMARY KEY (`datumid`),
  ADD KEY `deteid` (`deteid`),
  ADD KEY `aktivnostid` (`aktivnostid`);

--
-- Indexes for table `roditelj`
--
ALTER TABLE `roditelj`
  ADD PRIMARY KEY (`roditeljid`),
  ADD KEY `svojstvoid` (`svojstvoid`);

--
-- Indexes for table `svojstvo_roditelja`
--
ALTER TABLE `svojstvo_roditelja`
  ADD PRIMARY KEY (`svojstvoid`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `dete`
--
ALTER TABLE `dete`
  ADD CONSTRAINT `dete_ibfk_1` FOREIGN KEY (`polid`) REFERENCES `pol` (`polid`),
  ADD CONSTRAINT `dete_ibfk_2` FOREIGN KEY (`roditeljid`) REFERENCES `roditelj` (`roditeljid`);

--
-- Constraints for table `registar_aktivnosti`
--
ALTER TABLE `registar_aktivnosti`
  ADD CONSTRAINT `registar_aktivnosti_ibfk_1` FOREIGN KEY (`deteid`) REFERENCES `dete` (`deteid`),
  ADD CONSTRAINT `registar_aktivnosti_ibfk_2` FOREIGN KEY (`aktivnostid`) REFERENCES `aktivnosti` (`aktivnostid`);

--
-- Constraints for table `roditelj`
--
ALTER TABLE `roditelj`
  ADD CONSTRAINT `roditelj_ibfk_1` FOREIGN KEY (`svojstvoid`) REFERENCES `svojstvo_roditelja` (`svojstvoid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
