﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySqlConnector;

namespace A24_Poliklinika
{
    public partial class Form1 : Form
    {
        MySqlConnection konekcija = new MySqlConnection();
        MySqlCommand komanda = new MySqlCommand();
        DataTable tabela = new DataTable();
        MySqlDataAdapter adapter = new MySqlDataAdapter();
        DataSet podaci = new DataSet();
        MySqlDataReader rezultat;
        string upit;
        string temp = "server=localhost; user id=root; password=asd123; database=poliklinika";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            //dataGridView1.ReadOnly = true;
            dataGridView1.ClearSelection();

            punispecijalizacije();
        }
        private void punispecijalizacije() {

            comboBox1.Items.Clear();
            comboBox3.Items.Clear();
            comboBox1.Items.Add("Izaberite podatak:");
            comboBox3.Items.Add("Izaberite podatak:");
            konekcija.ConnectionString = temp;
            konekcija.Open();
            komanda.Connection = konekcija;
            upit = "SELECT * from tip_lekara";
            komanda.CommandText = upit;
            rezultat = komanda.ExecuteReader();
            tabela.Reset();
            tabela.Load(rezultat);
            for (int i = 0; i < tabela.Rows.Count; i++)
            {
                string s1 = tabela.Rows[i].ItemArray[0].ToString();
                string s2 = tabela.Rows[i].ItemArray[1].ToString();
                comboBox1.Items.Add(s2);
                comboBox3.Items.Add(s1);
            }

            rezultat.Close();
            konekcija.Close();
            comboBox1.SelectedIndex = 0;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox3.SelectedIndex = comboBox1.SelectedIndex;
            if (comboBox1.SelectedIndex != 0) {
                punilekare();
            }
            if (comboBox1.SelectedIndex == 0)
            {
                DataTable tabela = new DataTable();
                tabela.Reset();
                tabela.Load(rezultat);
                dataGridView1.DataSource = tabela;
                comboBox2.Text = "";
            }
        }
        private void punilekare() {

            comboBox2.Items.Clear();
            comboBox4.Items.Clear();
            comboBox2.Items.Add("Izaberite podatak:");
            comboBox4.Items.Add("Izaberite podatak:");

            konekcija.ConnectionString = temp;
            konekcija.Open();
            komanda.Connection = konekcija;
            upit = "SELECT lekar.lekarid,concat(lekar.ime,' ',lekar.prezime) from lekar WHERE lekar.tiplekaraid=" + comboBox3.Text;
            komanda.CommandText = upit;
            rezultat = komanda.ExecuteReader();
            tabela.Reset();
            tabela.Load(rezultat);
            for (int i = 0; i < tabela.Rows.Count; i++)
            {
                string s1 = tabela.Rows[i].ItemArray[0].ToString();
                string s2 = tabela.Rows[i].ItemArray[1].ToString();
                comboBox4.Items.Add(s1);
                comboBox2.Items.Add(s2);
            }

            rezultat.Close();
            konekcija.Close();
            comboBox2.SelectedIndex = 0;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox4.SelectedIndex = comboBox2.SelectedIndex;
            if (comboBox2.SelectedIndex != 0)
            {
                punigrid();
            }
            if (comboBox2.SelectedIndex == 0)
            {
                DataTable tabela = new DataTable();
                tabela.Reset();
                tabela.Load(rezultat);
                dataGridView1.DataSource = tabela;
                dataGridView1.ClearSelection();
            }
        }
        private void punigrid() {
            DataTable tabela = new DataTable();
            DataTable tabela2 = new DataTable();
            tabela.Columns.Add("Grad", typeof(string));
            tabela.Columns.Add("Poliklinika", typeof(string));
            tabela.Columns.Add("Status", typeof(bool));

            konekcija.ConnectionString = temp;
            konekcija.Open();
            komanda.Connection = konekcija;
            upit = "SELECT grad.grad as Grad,poliklinika.naziv as Poliklinika,poliklinika_specijalista.aktivan as Status from poliklinika INNER JOIN grad on poliklinika.gradid=grad.gradid INNER JOIN poliklinika_specijalista on poliklinika_specijalista.poliklinikaid=poliklinika.poliklinikaid where poliklinika_specijalista.lekarid=" + comboBox4.Text;
            komanda.CommandText = upit;
            rezultat = komanda.ExecuteReader();
            tabela2.Reset();
            tabela2.Load(rezultat);
            for (int i = 0; i < tabela2.Rows.Count; i++) {
                string s1 = tabela2.Rows[i].ItemArray[0].ToString();
                string s2 = tabela2.Rows[i].ItemArray[1].ToString();
                string s3 = tabela2.Rows[i].ItemArray[2].ToString();
                if (s3 == "da") s3 = "true";
                if (s3 == "ne") s3 = "false";
                tabela.Rows.Add(s1, s2, s3);
                dataGridView1.DataSource = tabela;

            }
            dataGridView1.ClearSelection();
            rezultat.Close();
            konekcija.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            int k = dataGridView1.CurrentRow.Index;

            konekcija.ConnectionString = temp;
            konekcija.Open();
            komanda.Connection = konekcija;
            upit = "SELECT poliklinika.poliklinikaid FROM poliklinika WHERE poliklinika.naziv='"+ dataGridView1.Rows[k].Cells[1].Value.ToString()+ "'";
            komanda.CommandText = upit;
            rezultat = komanda.ExecuteReader();
            tabela.Reset();
            tabela.Load(rezultat);
            label6.Text = tabela.Rows[0].ItemArray[0].ToString();
            rezultat.Close();
            konekcija.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int k = dataGridView1.CurrentRow.Index;
            if ((bool)dataGridView1.Rows[k].Cells[2].Value == false) { aktivanne(); }
            else aktivanda();
                
        }
        private void aktivanda() {

            konekcija.ConnectionString = temp;
            konekcija.Open();
            komanda.Connection = konekcija;
            upit = "update poliklinika_specijalista set poliklinika_specijalista.aktivan='da' where poliklinika_specijalista.poliklinikaid=" + label6.Text + " AND poliklinika_specijalista.lekarid=" + comboBox4.Text;
            komanda.CommandText = upit;
            rezultat = komanda.ExecuteReader();
            tabela.Reset();
            tabela.Load(rezultat);

            rezultat.Close();
            konekcija.Close();
            punigrid();
            MessageBox.Show("Uspesna izmena!");
        }
        private void aktivanne()
        {

            konekcija.ConnectionString = temp;
            konekcija.Open();
            komanda.Connection = konekcija;
            upit = "update poliklinika_specijalista set poliklinika_specijalista.aktivan='ne' where poliklinika_specijalista.poliklinikaid=" + label6.Text + " AND poliklinika_specijalista.lekarid=" + comboBox4.Text;
            komanda.CommandText = upit;
            rezultat = komanda.ExecuteReader();
            tabela.Reset();
            tabela.Load(rezultat);

            rezultat.Close();
            konekcija.Close();
            punigrid();
            MessageBox.Show("Uspesna izmena!");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true) punipogradovima();
            if (radioButton2.Checked == true) punipospecijalizacijama();
            if (radioButton3.Checked == true) punipoklinikama();


        }
        private void punipogradovima() {
            chart1.Series.Clear();
            chart1.Series.Add("Grad");
            string datumod = dateTimePicker1.Text.Substring(6, 4) + "-" + dateTimePicker1.Text.Substring(3, 2) + "-" + dateTimePicker1.Text.Substring(0, 2);
            string datumdo = dateTimePicker2.Text.Substring(6, 4) + "-" + dateTimePicker2.Text.Substring(3, 2) + "-" + dateTimePicker2.Text.Substring(0, 2);

                chart1.Titles.Clear();
                chart1.Titles.Add("Grafik prikaza broja pregleda po gradovima");

                konekcija.ConnectionString = temp;
                konekcija.Open();
                komanda.Connection = konekcija;
                upit = "SELECT COUNT(*) as Broj,grad.grad as Grad from zakazivanje INNER JOIN poliklinika on poliklinika.poliklinikaid=zakazivanje.poliklinikaid INNER JOIN grad on poliklinika.gradid=grad.gradid where zakazivanje.datumzakazivanja>='"+datumod+ "' AND zakazivanje.datumzakazivanja<='"+datumdo+"' GROUP by grad.grad";
                DataTable tabela2 = new DataTable();
                komanda.CommandText = upit;
                rezultat = komanda.ExecuteReader();
                tabela2.Reset();
                tabela2.Load(rezultat);

                chart1.ChartAreas[0].AxisX.Title = "Grad";
                chart1.ChartAreas[0].AxisY.Title = "Broj pregleda";


                chart1.DataSource = tabela2;
                chart1.Series["Grad"].XValueMember = "Grad";
                chart1.Series["Grad"].YValueMembers = "Broj";
                rezultat.Close();
                konekcija.Close();
        }
        private void punipospecijalizacijama() {
            chart1.Series.Clear();
            chart1.Series.Add("Specijalizacija");
            string datumod = dateTimePicker1.Text.Substring(6, 4) + "-" + dateTimePicker1.Text.Substring(3, 2) + "-" + dateTimePicker1.Text.Substring(0, 2);
            string datumdo = dateTimePicker2.Text.Substring(6, 4) + "-" + dateTimePicker2.Text.Substring(3, 2) + "-" + dateTimePicker2.Text.Substring(0, 2);

            chart1.Titles.Clear();
                chart1.Titles.Add("Grafik prikaza broja pregleda po specijalizacijama");

                konekcija.ConnectionString = temp;
                konekcija.Open();
                komanda.Connection = konekcija;
                upit = "SELECT COUNT(*) as Broj,tip_lekara.tip as Specijalizacija FROM zakazivanje INNER JOIN lekar on lekar.lekarid=zakazivanje.lekarid INNER JOIN tip_lekara ON lekar.tiplekaraid=tip_lekara.tiplekaraid where zakazivanje.datumzakazivanja>='" + datumod + "' AND zakazivanje.datumzakazivanja<='" + datumdo + "' GROUP by tip_lekara.tip;";
                DataTable tabela2 = new DataTable();
                komanda.CommandText = upit;
                rezultat = komanda.ExecuteReader();
                tabela2.Reset();
                tabela2.Load(rezultat);

                chart1.ChartAreas[0].AxisX.Title = "Specijalizacija";
                chart1.ChartAreas[0].AxisY.Title = "Broj pregleda";


                chart1.DataSource = tabela2;
                chart1.Series["Specijalizacija"].XValueMember = "Specijalizacija";
                chart1.Series["Specijalizacija"].YValueMembers = "Broj";
                rezultat.Close();
                konekcija.Close();
        }
        private void punipoklinikama() {
            chart1.Series.Clear();
            chart1.Series.Add("Klinika");
            string datumod = dateTimePicker1.Text.Substring(6, 4) + "-" + dateTimePicker1.Text.Substring(3, 2) + "-" + dateTimePicker1.Text.Substring(0, 2);
            string datumdo = dateTimePicker2.Text.Substring(6, 4) + "-" + dateTimePicker2.Text.Substring(3, 2) + "-" + dateTimePicker2.Text.Substring(0, 2);

            chart1.Titles.Clear();
            chart1.Titles.Add("Grafik prikaza broja pregleda po klinikama");

            konekcija.ConnectionString = temp;
            konekcija.Open();
            komanda.Connection = konekcija;
            upit = "SELECT COUNT(*) as Broj,poliklinika.naziv as Klinika from zakazivanje INNER JOIN poliklinika on poliklinika.poliklinikaid=zakazivanje.poliklinikaid where zakazivanje.datumzakazivanja>='" + datumod + "' AND zakazivanje.datumzakazivanja<='" + datumdo + "' GROUP by poliklinika.naziv;";
            DataTable tabela2 = new DataTable();
            komanda.CommandText = upit;
            rezultat = komanda.ExecuteReader();
            tabela2.Reset();
            tabela2.Load(rezultat);

            chart1.ChartAreas[0].AxisX.Title = "Klinika";
            chart1.ChartAreas[0].AxisY.Title = "Broj pregleda";


            chart1.DataSource = tabela2;
            chart1.Series["Klinika"].XValueMember = "Klinika";
            chart1.Series["Klinika"].YValueMembers = "Broj";
            rezultat.Close();
            konekcija.Close();
        }
        private void radioButton1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true) {
                radioButton2.Checked = false;
                radioButton3.Checked = false;
            }
        }

        private void radioButton2_Click(object sender, EventArgs e)
        {
            if (radioButton2.Checked == true)
            {
                radioButton1.Checked = false;
                radioButton3.Checked = false;
            }
        }

        private void radioButton3_Click(object sender, EventArgs e)
        {
            if (radioButton3.Checked == true)
            {
                radioButton1.Checked = false;
                radioButton2.Checked = false;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
