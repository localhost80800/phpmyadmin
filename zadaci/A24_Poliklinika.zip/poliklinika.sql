-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2023 at 06:50 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `poliklinika`
--

-- --------------------------------------------------------

--
-- Table structure for table `grad`
--

CREATE TABLE `grad` (
  `gradid` int(11) NOT NULL,
  `grad` varchar(45) DEFAULT NULL,
  `pozivnibroj` int(11) DEFAULT NULL,
  `postanskibroj` int(11) DEFAULT NULL,
  `brojstanovnika` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `grad`
--

INSERT INTO `grad` (`gradid`, `grad`, `pozivnibroj`, `postanskibroj`, `brojstanovnika`) VALUES
(1, 'mladenovac', 641248328, 11400, 500000),
(2, 'milanovac', 645486157, 11500, 150000),
(3, 'novi sad', 638465154, 11650, 250000),
(4, 'kragujevac', 624868484, 11250, 650000),
(5, 'pirot', 675468156, 11560, 758000);

-- --------------------------------------------------------

--
-- Table structure for table `lekar`
--

CREATE TABLE `lekar` (
  `lekarid` int(11) NOT NULL,
  `ime` varchar(45) NOT NULL,
  `prezime` varchar(45) NOT NULL,
  `brojtelefona` int(11) NOT NULL,
  `tiplekaraid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `lekar`
--

INSERT INTO `lekar` (`lekarid`, `ime`, `prezime`, `brojtelefona`, `tiplekaraid`) VALUES
(4568, 'aleksandar', 'stojic', 648643156, 4568),
(4589, 'milos', 'simic', 655484555, 46483),
(4648, 'filip', 'dimitrijevic', 642458354, 548463),
(6748, 'sava', 'jovanovic', 654854865, 55987),
(8687, 'djordje', 'brkic', 635522676, 59483);

-- --------------------------------------------------------

--
-- Table structure for table `pacijent`
--

CREATE TABLE `pacijent` (
  `pacijentid` int(11) NOT NULL,
  `ime` varchar(45) DEFAULT NULL,
  `prezime` varchar(45) DEFAULT NULL,
  `adresa` varchar(45) DEFAULT NULL,
  `gradid` int(11) DEFAULT NULL,
  `brojtelefona` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pacijent`
--

INSERT INTO `pacijent` (`pacijentid`, `ime`, `prezime`, `adresa`, `gradid`, `brojtelefona`) VALUES
(45, 'ivan', 'kukic', 'mihaila milovanovica', 4, 645284651),
(312, 'bozidar', 'ilic', 'sopotska ', 3, 68451265),
(321, 'djordje', 'kikic', 'vuka karadzica', 2, 614587354),
(542, 'stefan', 'zivotic', 'crkvena', 2, 675532548),
(545, 'goran', 'jankovic', 'skolska', 1, 652184654);

-- --------------------------------------------------------

--
-- Table structure for table `poliklinika`
--

CREATE TABLE `poliklinika` (
  `poliklinikaid` int(11) NOT NULL,
  `naziv` varchar(45) DEFAULT NULL,
  `adresa` varchar(45) DEFAULT NULL,
  `telefon` int(11) DEFAULT NULL,
  `sajt` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `gradid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `poliklinika`
--

INSERT INTO `poliklinika` (`poliklinikaid`, `naziv`, `adresa`, `telefon`, `sajt`, `email`, `gradid`) VALUES
(12, 'Kuća zdravlja', '19350 Knjaževac', 614586543, 'dsafsdfasdfu.com', 'sfasdfasdfasf@gmail.com', 5),
(32, 'Sirmai', ' Grčkoškolskoj', 624586452, 'fadsfa8dsfhu.com', 'dsafdsa@gmail.com', 1),
(45, 'SMD Medic', 'jovana Popovića 7', 65134586, 'sdafadsfasdfasdf.com', 'asdasd@gmail.com', 4),
(64, 'Centar', 'Senćanski put 15', 63458641, 'asdfasdufghv.com', 'fdasfasdfasf@gmail.com', 2),
(65, 'Poliklinike Temerin', 'Centar Ulica', 645486254, 'fasdfasduhuf.com', 'dfgasdfae@gmail.com', 3);

-- --------------------------------------------------------

--
-- Table structure for table `poliklinika_specijalista`
--

CREATE TABLE `poliklinika_specijalista` (
  `poliklinikaid` int(11) NOT NULL,
  `lekarid` int(11) NOT NULL,
  `aktivan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `poliklinika_specijalista`
--

INSERT INTO `poliklinika_specijalista` (`poliklinikaid`, `lekarid`, `aktivan`) VALUES
(32, 8687, 'da'),
(45, 4648, 'ne'),
(64, 4589, 'da'),
(64, 4648, 'da'),
(65, 6748, 'ne');

-- --------------------------------------------------------

--
-- Table structure for table `tip_lekara`
--

CREATE TABLE `tip_lekara` (
  `tiplekaraid` int(11) NOT NULL,
  `tip` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tip_lekara`
--

INSERT INTO `tip_lekara` (`tiplekaraid`, `tip`) VALUES
(4568, 'hirurg'),
(46483, 'Kardiolog'),
(55987, 'Oftalmolog'),
(59483, 'Neurolog'),
(548463, 'Genetičar');

-- --------------------------------------------------------

--
-- Table structure for table `zakazivanje`
--

CREATE TABLE `zakazivanje` (
  `pacijentid` int(11) NOT NULL,
  `poliklinikaid` int(11) NOT NULL,
  `datumzakazivanja` date NOT NULL,
  `lekarid` int(11) NOT NULL,
  `komentar` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zakazivanje`
--

INSERT INTO `zakazivanje` (`pacijentid`, `poliklinikaid`, `datumzakazivanja`, `lekarid`, `komentar`) VALUES
(45, 12, '2023-01-03', 6748, 'izvadite krv 2 dana pre dolaska'),
(312, 32, '2023-01-11', 4648, 'obavezno donesite masku'),
(321, 65, '2023-01-24', 4589, 'dodjite 20 minuta pre dolaska'),
(542, 32, '2023-01-12', 4568, 'dodjite 15 minuta i doesite krv'),
(545, 64, '2023-01-13', 4648, 'donesite testove od prosle nedelje');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `grad`
--
ALTER TABLE `grad`
  ADD PRIMARY KEY (`gradid`);

--
-- Indexes for table `lekar`
--
ALTER TABLE `lekar`
  ADD PRIMARY KEY (`lekarid`),
  ADD KEY `tiplekaraid` (`tiplekaraid`);

--
-- Indexes for table `pacijent`
--
ALTER TABLE `pacijent`
  ADD PRIMARY KEY (`pacijentid`),
  ADD KEY `gradid` (`gradid`);

--
-- Indexes for table `poliklinika`
--
ALTER TABLE `poliklinika`
  ADD PRIMARY KEY (`poliklinikaid`),
  ADD KEY `gradid` (`gradid`);

--
-- Indexes for table `poliklinika_specijalista`
--
ALTER TABLE `poliklinika_specijalista`
  ADD PRIMARY KEY (`poliklinikaid`,`lekarid`),
  ADD KEY `lekarid` (`lekarid`);

--
-- Indexes for table `tip_lekara`
--
ALTER TABLE `tip_lekara`
  ADD PRIMARY KEY (`tiplekaraid`);

--
-- Indexes for table `zakazivanje`
--
ALTER TABLE `zakazivanje`
  ADD PRIMARY KEY (`pacijentid`,`poliklinikaid`,`datumzakazivanja`,`lekarid`),
  ADD KEY `poliklinikaid` (`poliklinikaid`),
  ADD KEY `lekarid` (`lekarid`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `lekar`
--
ALTER TABLE `lekar`
  ADD CONSTRAINT `lekar_ibfk_1` FOREIGN KEY (`tiplekaraid`) REFERENCES `tip_lekara` (`tiplekaraid`);

--
-- Constraints for table `pacijent`
--
ALTER TABLE `pacijent`
  ADD CONSTRAINT `pacijent_ibfk_1` FOREIGN KEY (`gradid`) REFERENCES `grad` (`gradid`);

--
-- Constraints for table `poliklinika`
--
ALTER TABLE `poliklinika`
  ADD CONSTRAINT `poliklinika_ibfk_1` FOREIGN KEY (`gradid`) REFERENCES `grad` (`gradid`);

--
-- Constraints for table `poliklinika_specijalista`
--
ALTER TABLE `poliklinika_specijalista`
  ADD CONSTRAINT `poliklinika_specijalista_ibfk_1` FOREIGN KEY (`poliklinikaid`) REFERENCES `poliklinika` (`poliklinikaid`),
  ADD CONSTRAINT `poliklinika_specijalista_ibfk_2` FOREIGN KEY (`lekarid`) REFERENCES `lekar` (`lekarid`);

--
-- Constraints for table `zakazivanje`
--
ALTER TABLE `zakazivanje`
  ADD CONSTRAINT `zakazivanje_ibfk_1` FOREIGN KEY (`pacijentid`) REFERENCES `pacijent` (`pacijentid`),
  ADD CONSTRAINT `zakazivanje_ibfk_2` FOREIGN KEY (`poliklinikaid`) REFERENCES `poliklinika` (`poliklinikaid`),
  ADD CONSTRAINT `zakazivanje_ibfk_3` FOREIGN KEY (`lekarid`) REFERENCES `lekar` (`lekarid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
