-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2023 at 04:52 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fudbalski_stadion`
--

-- --------------------------------------------------------

--
-- Table structure for table `drzava`
--

CREATE TABLE `drzava` (
  `drzavaid` int(11) NOT NULL,
  `naziv` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `drzava`
--

INSERT INTO `drzava` (`drzavaid`, `naziv`) VALUES
(1010, 'Svajcarska'),
(1111, 'Engleska'),
(2222, 'Nemacka'),
(3333, 'Italija'),
(4444, 'Spanija'),
(5555, 'Srbija'),
(6666, 'Hrvatska'),
(7777, 'Francuska'),
(8888, 'Danska'),
(9999, 'Austrija');

-- --------------------------------------------------------

--
-- Table structure for table `grad`
--

CREATE TABLE `grad` (
  `gradid` int(11) NOT NULL,
  `grad` varchar(30) DEFAULT NULL,
  `pozivnibroj` int(11) DEFAULT NULL,
  `postanskibroj` int(11) DEFAULT NULL,
  `brojstanovnika` int(11) DEFAULT NULL,
  `drzavaid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `grad`
--

INSERT INTO `grad` (`gradid`, `grad`, `pozivnibroj`, `postanskibroj`, `brojstanovnika`, `drzavaid`) VALUES
(1010, 'Bern', 9990, 1009, 190000, 1010),
(1111, 'London', 9999, 1000, 100000, 1111),
(2222, 'Berlin', 9998, 1001, 110000, 2222),
(3333, 'Rim', 9997, 1002, 120000, 3333),
(4444, 'Madrid', 9996, 1003, 130000, 4444),
(5555, 'Beograd', 9995, 1004, 140000, 5555),
(6666, 'Zagreb', 9994, 1005, 150000, 6666),
(7777, 'Pariz', 9993, 1006, 160000, 7777),
(8888, 'Kopenhagen', 9992, 1007, 170000, 8888),
(9999, 'Bec', 9991, 1008, 180000, 9999);

-- --------------------------------------------------------

--
-- Table structure for table `klub`
--

CREATE TABLE `klub` (
  `klubid` int(11) NOT NULL,
  `nazivkluba` varchar(30) DEFAULT NULL,
  `stadionid` int(11) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `sajt` varchar(50) DEFAULT NULL,
  `ziroracun` int(11) DEFAULT NULL,
  `amblem` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `klub`
--

INSERT INTO `klub` (`klubid`, `nazivkluba`, `stadionid`, `email`, `sajt`, `ziroracun`, `amblem`) VALUES
(1010, 'Sumari', 1010, 'sumari@gmail.com', 'www.sumari.com', 1110, 'Sekira'),
(1111, 'Arsenal', 1111, 'Arsenal@gmail.com', 'www.arsenal.com', 1101, 'Topovi'),
(2222, 'Roma', 2222, 'roma@gmail.com', 'www.roma.com', 1102, 'Pas'),
(3333, 'PSG', 3333, 'psg@gmail.com', 'www.psg.com', 1103, 'Ajfelov toranj'),
(4444, 'Real Madrid', 4444, 'real@gmail.com', 'www.real.com', 1104, 'Belo plavo'),
(5555, 'FK Kusadak', 5555, 'fkkusadak@gmail.com', 'www.fkkusadak.com', 1105, 'Pivo'),
(6666, 'Lokomotiva', 6666, 'lokomotiva@gmail.com', 'www.lokomotiva.com', 1106, 'Lokomotiva'),
(7777, 'Miloseva', 7777, 'milos@gmail.com', 'www.milos.com', 1107, 'Zajecarsko'),
(8888, 'Moskvaa', 8888, 'moskvaa@gmail.com', 'www.moskvaa.com', 1108, 'Crkva'),
(9999, 'Rapid Wien', 9999, 'rapid@gmail.com', 'www.rapid.com', 1109, 'Pistolj');

-- --------------------------------------------------------

--
-- Table structure for table `stadion`
--

CREATE TABLE `stadion` (
  `stadionid` int(11) NOT NULL,
  `naziv` varchar(30) DEFAULT NULL,
  `adresa` varchar(30) DEFAULT NULL,
  `kapacitet` int(11) DEFAULT NULL,
  `brojulaza` int(11) DEFAULT NULL,
  `gradid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stadion`
--

INSERT INTO `stadion` (`stadionid`, `naziv`, `adresa`, `kapacitet`, `brojulaza`, `gradid`) VALUES
(1010, 'Sumar7777', 'Bern 10000', 100000, 10, 1010),
(1111, 'Wembly2', 'London 11', 100000, 16, 1111),
(2222, 'Der Alten', 'Berlin 12', 150000, 16, 2222),
(3333, 'Lavity', 'Rim 13', 130000, 15, 3333),
(4444, 'San Tjago Bernabeu', 'Madrid 14', 140000, 14, 4444),
(5555, 'Tunel2', 'Kusadak 15', 1500, 2, 1010),
(6666, 'Kolina', 'Zagreb 16', 16000, 6, 6666),
(7777, 'Mishaa', 'Pariz 17', 170000, 17, 7777),
(8888, 'Harosh', 'Kopenhagen 18', 180000, 18, 8888),
(9999, 'Nigga', 'Zagrebacka 69', 251521, 19, 6666);

-- --------------------------------------------------------

--
-- Table structure for table `takmicenje`
--

CREATE TABLE `takmicenje` (
  `takmicenjeid` int(11) NOT NULL,
  `naziv` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `takmicenje`
--

INSERT INTO `takmicenje` (`takmicenjeid`, `naziv`) VALUES
(1010, 'Za Bojana'),
(1111, 'Za Milosa'),
(2222, 'Za Mihajla'),
(3333, 'Za Jovana'),
(4444, 'Za Nemanju'),
(5555, 'Za Cvarka'),
(6666, 'Za Milicu'),
(7777, 'Za Luku'),
(8888, 'Za Nikolu'),
(9999, 'Za Aleksu');

-- --------------------------------------------------------

--
-- Table structure for table `utakmica`
--

CREATE TABLE `utakmica` (
  `utakmicaid` int(11) NOT NULL,
  `datumigranja` date DEFAULT NULL,
  `vremeigranja` time DEFAULT NULL,
  `takmicenjeid` int(11) DEFAULT NULL,
  `domacinid` int(11) DEFAULT NULL,
  `gostid` int(11) DEFAULT NULL,
  `golovadomacin` int(11) DEFAULT NULL,
  `golovagost` int(11) DEFAULT NULL,
  `klubid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `utakmica`
--

INSERT INTO `utakmica` (`utakmicaid`, `datumigranja`, `vremeigranja`, `takmicenjeid`, `domacinid`, `gostid`, `golovadomacin`, `golovagost`, `klubid`) VALUES
(1010, '2022-06-16', '22:00:00', 1010, 1010, 4444, 0, 0, 1010),
(1111, '2022-06-15', '17:00:00', 1111, 1111, 4444, 1, 0, 1111),
(2222, '2022-06-01', '00:00:00', 2222, 2222, 3333, 3, 2, 2222),
(3333, NULL, NULL, 3333, 3333, 1010, 3, 1, 3333),
(4444, '2022-06-10', '20:00:00', 4444, 4444, 5555, 2, 2, 4444),
(5555, '2022-06-04', '15:00:00', 5555, 5555, 2222, 3, 1, 5555),
(6666, '2022-06-13', '20:00:00', 6666, 6666, 3333, 1, 3, 6666),
(7777, '2022-06-22', '18:00:00', 7777, 7777, 3333, 2, 4, 7777),
(8888, '2022-06-29', '21:00:00', 8888, 8888, 9999, 2, 1, 8888),
(9999, '2022-06-30', '14:00:00', 9999, 9999, 1111, 3, 0, 9999);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `drzava`
--
ALTER TABLE `drzava`
  ADD PRIMARY KEY (`drzavaid`);

--
-- Indexes for table `grad`
--
ALTER TABLE `grad`
  ADD PRIMARY KEY (`gradid`),
  ADD KEY `drzavaid` (`drzavaid`);

--
-- Indexes for table `klub`
--
ALTER TABLE `klub`
  ADD PRIMARY KEY (`klubid`),
  ADD KEY `stadionid` (`stadionid`);

--
-- Indexes for table `stadion`
--
ALTER TABLE `stadion`
  ADD PRIMARY KEY (`stadionid`),
  ADD KEY `gradid` (`gradid`);

--
-- Indexes for table `takmicenje`
--
ALTER TABLE `takmicenje`
  ADD PRIMARY KEY (`takmicenjeid`);

--
-- Indexes for table `utakmica`
--
ALTER TABLE `utakmica`
  ADD PRIMARY KEY (`utakmicaid`),
  ADD KEY `takmicenjeid` (`takmicenjeid`),
  ADD KEY `klubid` (`klubid`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `grad`
--
ALTER TABLE `grad`
  ADD CONSTRAINT `grad_ibfk_1` FOREIGN KEY (`drzavaid`) REFERENCES `drzava` (`drzavaid`);

--
-- Constraints for table `klub`
--
ALTER TABLE `klub`
  ADD CONSTRAINT `klub_ibfk_1` FOREIGN KEY (`stadionid`) REFERENCES `stadion` (`stadionid`);

--
-- Constraints for table `stadion`
--
ALTER TABLE `stadion`
  ADD CONSTRAINT `stadion_ibfk_1` FOREIGN KEY (`gradid`) REFERENCES `grad` (`gradid`);

--
-- Constraints for table `utakmica`
--
ALTER TABLE `utakmica`
  ADD CONSTRAINT `utakmica_ibfk_1` FOREIGN KEY (`takmicenjeid`) REFERENCES `takmicenje` (`takmicenjeid`),
  ADD CONSTRAINT `utakmica_ibfk_2` FOREIGN KEY (`klubid`) REFERENCES `klub` (`klubid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
