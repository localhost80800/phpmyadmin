-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2023 at 06:43 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `evidencija_vozila`
--

-- --------------------------------------------------------

--
-- Table structure for table `auto_oprema`
--

CREATE TABLE `auto_oprema` (
  `VoziloID` int(11) NOT NULL,
  `OpremaID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auto_oprema`
--

INSERT INTO `auto_oprema` (`VoziloID`, `OpremaID`) VALUES
(70, 11),
(71, 22),
(72, 122),
(73, 77),
(74, 99),
(75, 144),
(76, 100),
(77, 44),
(78, 66),
(79, 33),
(80, 155),
(81, 111),
(82, 55),
(83, 133),
(84, 88);

-- --------------------------------------------------------

--
-- Table structure for table `boja`
--

CREATE TABLE `boja` (
  `BojaID` int(11) NOT NULL,
  `Naziv` varchar(25) DEFAULT NULL,
  `OpisBoje` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `boja`
--

INSERT INTO `boja` (`BojaID`, `Naziv`, `OpisBoje`) VALUES
(900, 'Crvena', 'Metalik'),
(901, 'Bela', 'Mat'),
(902, 'Plava', 'Metalik'),
(903, 'Zelena', 'Metalik'),
(904, 'Zuta', 'Mat'),
(905, 'Roze', 'Svetla'),
(906, 'Ljubicasta', 'Tamna'),
(907, 'Siva', 'Nardo'),
(908, 'Crna', 'Mat'),
(909, 'Tirkizna plava', 'Metalik'),
(910, 'Drecava zelena', 'Metalik'),
(911, 'Teget plava', 'Metalik'),
(912, 'Braon', 'Mat'),
(913, 'Narandzasta', 'Tamna'),
(914, 'Violetna ljubicasta', 'Metalik');

-- --------------------------------------------------------

--
-- Table structure for table `gorivo`
--

CREATE TABLE `gorivo` (
  `GorivoID` int(11) NOT NULL,
  `Opis` varchar(25) DEFAULT NULL,
  `Naziv` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gorivo`
--

INSERT INTO `gorivo` (`GorivoID`, `Opis`, `Naziv`) VALUES
(21, 'Najjaci benzin', 'Gdrive 100'),
(22, 'Skoro najjaci benzin', 'Gdrive 98'),
(23, 'Dobar benzin', 'Gdrive 95'),
(24, 'Za vozila i traktore', 'Gdrive Dizel'),
(25, 'Benzin ekstra', 'BMB 95'),
(26, 'Maksimalne performanse vo', 'Evro dizel'),
(27, 'Gas novije generacije', 'Auto GAS Opti'),
(28, 'Prirodni gas', 'Metan CNG'),
(29, 'Aditivni benzin', 'Benzin OPTI 95'),
(30, 'Aditiviran Evro Dizel', 'Dizel OPTI'),
(31, 'Povecava oktanske vrednos', 'Evro BMB 98'),
(32, 'Gorivo vrhunskog kvalitet', 'Evro premium'),
(33, 'Za elektricna vozila', 'Elektropunjaci'),
(34, 'Najvisi kvalitet i najsku', 'Dizel plus'),
(35, 'Dodaje pojacane specijaln', 'Expert BMB');

-- --------------------------------------------------------

--
-- Table structure for table `model`
--

CREATE TABLE `model` (
  `ModelID` int(11) NOT NULL,
  `Naziv` varchar(25) DEFAULT NULL,
  `ProizvodjacID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `model`
--

INSERT INTO `model` (`ModelID`, `Naziv`, `ProizvodjacID`) VALUES
(50, 'Skala 55', 1),
(51, 'Corsa', 2),
(52, '320d', 3),
(53, 'A4', 4),
(54, 'S500', 5),
(55, 'Sandero', 6),
(56, 'Focus', 7),
(57, 'Octavia', 8),
(58, '206', 9),
(59, 'C3', 10),
(60, 'Corolla', 11),
(61, 'Punto', 12),
(62, '147', 13),
(63, 'Civic', 14),
(64, 'Golf 5', 15);

-- --------------------------------------------------------

--
-- Table structure for table `oprema`
--

CREATE TABLE `oprema` (
  `OpremaID` int(11) NOT NULL,
  `Naziv` varchar(25) DEFAULT NULL,
  `Opis` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oprema`
--

INSERT INTO `oprema` (`OpremaID`, `Naziv`, `Opis`) VALUES
(11, 'Auspuh Eisenmann', 'Da se mangupirate'),
(22, 'Folija za stakla', 'Da metci ne mogu da probi'),
(33, 'Tempomat', 'Zakljucava brzinu'),
(44, 'Klima', 'Ladi auto'),
(55, 'Rikverc svetlo', 'Sija kad ubacim u rikverc'),
(66, 'Maglenka', 'Svetlo za maglu'),
(77, 'Sociva u farovima', 'Bolje sijaju'),
(88, 'Recaro Sedista', 'Sportska sedista za udobn'),
(99, 'Set za krpljenje', 'Ako vas ostavi na putu'),
(100, 'Karbonski krov', 'Za smanjenu kilazu'),
(111, 'Aerodinamicni retrovizori', 'Za bolju aerodinamiku'),
(122, 'Super branici', 'Sportska opema'),
(133, 'Kablovi za startovanje', 'Ukoliko vam se isprazni a'),
(144, 'Brisaci', 'Da progledate'),
(155, 'Dizalica', 'Da ga dizete');

-- --------------------------------------------------------

--
-- Table structure for table `proizvodjac`
--

CREATE TABLE `proizvodjac` (
  `ProizvodjacID` int(11) NOT NULL,
  `Naziv` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `proizvodjac`
--

INSERT INTO `proizvodjac` (`ProizvodjacID`, `Naziv`) VALUES
(1, 'Zastava'),
(2, 'Opel'),
(3, 'BMW'),
(4, 'Audi'),
(5, 'Mercedes'),
(6, 'Dacia'),
(7, 'Ford'),
(8, 'Skoda'),
(9, 'Peugeot'),
(10, 'Citroen'),
(11, 'Toyota'),
(12, 'Fiat'),
(13, 'Alfa Romeo'),
(14, 'Honda'),
(15, 'Wolksvagen');

-- --------------------------------------------------------

--
-- Table structure for table `vozilo`
--

CREATE TABLE `vozilo` (
  `VoziloID` int(11) NOT NULL,
  `Registracija` varchar(25) DEFAULT NULL,
  `GodinaProizvodnje` date DEFAULT NULL,
  `PredjenoKM` int(11) DEFAULT NULL,
  `ModelID` int(11) DEFAULT NULL,
  `BojaID` int(11) DEFAULT NULL,
  `GorivoID` int(11) DEFAULT NULL,
  `Cena` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vozilo`
--

INSERT INTO `vozilo` (`VoziloID`, `Registracija`, `GodinaProizvodnje`, `PredjenoKM`, `ModelID`, `BojaID`, `GorivoID`, `Cena`) VALUES
(42, 'SP-053-BC', '2005-06-12', 150000, 64, 908, 30, 6000),
(65, 'BG-1927-EE', '2008-01-01', 251000, 53, 903, 24, 4800),
(70, 'BG-1296-GG', '2002-01-01', 250000, 52, 903, 30, 25000),
(71, 'SP-026-YО', '2002-01-01', 125000, 58, 902, 29, 1700),
(72, 'TO-030-BE', '2010-07-05', 500000, 52, 908, 25, 4500),
(73, 'TO-027-DS', '2004-11-14', 390000, 53, 908, 23, 4000),
(74, 'TO-017-HG', '2002-10-24', 190000, 59, 901, 35, 2500),
(75, 'BG-1337-LO', '1999-01-01', 235000, 63, 909, 23, 3000),
(76, 'SP-225-MN', '2005-07-15', 145000, 60, 914, 32, 4000),
(77, 'SU-021-RE', '2003-09-14', 600000, 51, 912, 26, 1500),
(78, 'TO-007-JB', '2001-02-04', 300000, 56, 905, 21, 2500),
(79, 'TO-036-XC', '2005-12-23', 250000, 64, 904, 34, 4000),
(80, 'BG-1992-JU', '2007-03-18', 200000, 57, 910, 31, 5000),
(81, 'BG-452-VV', '2008-10-11', 100000, 61, 911, 28, 1500),
(82, 'TO-011-AQ', '2000-01-01', 130000, 54, 907, 22, 150000),
(83, 'SP-044-MC', '2011-07-22', 400000, 55, 906, 33, 10000),
(84, 'TO-009-SO', '1989-04-16', 60000, 50, 900, 24, 500);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auto_oprema`
--
ALTER TABLE `auto_oprema`
  ADD PRIMARY KEY (`VoziloID`,`OpremaID`),
  ADD KEY `OpremaID` (`OpremaID`);

--
-- Indexes for table `boja`
--
ALTER TABLE `boja`
  ADD PRIMARY KEY (`BojaID`);

--
-- Indexes for table `gorivo`
--
ALTER TABLE `gorivo`
  ADD PRIMARY KEY (`GorivoID`);

--
-- Indexes for table `model`
--
ALTER TABLE `model`
  ADD PRIMARY KEY (`ModelID`),
  ADD KEY `ProizvodjacID` (`ProizvodjacID`);

--
-- Indexes for table `oprema`
--
ALTER TABLE `oprema`
  ADD PRIMARY KEY (`OpremaID`);

--
-- Indexes for table `proizvodjac`
--
ALTER TABLE `proizvodjac`
  ADD PRIMARY KEY (`ProizvodjacID`);

--
-- Indexes for table `vozilo`
--
ALTER TABLE `vozilo`
  ADD PRIMARY KEY (`VoziloID`),
  ADD KEY `BojaID` (`BojaID`),
  ADD KEY `ModelID` (`ModelID`),
  ADD KEY `GorivoID` (`GorivoID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auto_oprema`
--
ALTER TABLE `auto_oprema`
  ADD CONSTRAINT `auto_oprema_ibfk_1` FOREIGN KEY (`OpremaID`) REFERENCES `oprema` (`OpremaID`),
  ADD CONSTRAINT `auto_oprema_ibfk_2` FOREIGN KEY (`VoziloID`) REFERENCES `vozilo` (`VoziloID`),
  ADD CONSTRAINT `auto_oprema_ibfk_3` FOREIGN KEY (`VoziloID`) REFERENCES `vozilo` (`VoziloID`);

--
-- Constraints for table `model`
--
ALTER TABLE `model`
  ADD CONSTRAINT `model_ibfk_1` FOREIGN KEY (`ProizvodjacID`) REFERENCES `proizvodjac` (`ProizvodjacID`);

--
-- Constraints for table `vozilo`
--
ALTER TABLE `vozilo`
  ADD CONSTRAINT `vozilo_ibfk_1` FOREIGN KEY (`BojaID`) REFERENCES `boja` (`BojaID`),
  ADD CONSTRAINT `vozilo_ibfk_2` FOREIGN KEY (`ModelID`) REFERENCES `model` (`ModelID`),
  ADD CONSTRAINT `vozilo_ibfk_3` FOREIGN KEY (`GorivoID`) REFERENCES `gorivo` (`GorivoID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
