﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySqlConnector;

namespace A11_Evidencija_knjiga
{
    public partial class Form1 : Form
    {
        Form2 f2 = new Form2();
        MySqlConnection konekcija = new MySqlConnection();
        MySqlCommand komanda = new MySqlCommand();
        DataTable tabela = new DataTable();
        MySqlDataAdapter adapter = new MySqlDataAdapter();
        DataSet podaci = new DataSet();
        MySqlDataReader rezultat;
        string upit;
        string temp = "server=localhost; user id=root; password=asd123; allowZeroDateTime=true; convertZeroDateTime=true; database=evidencija_knjiga";
        string razmak = "                    ";
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            load();
        }
        private void load() {
            listBox1.Items.Clear();
            konekcija.ConnectionString = temp;
            konekcija.Open();
            komanda.Connection = konekcija;
            upit = "Select * from autor";
            komanda.CommandText = upit;
            rezultat = komanda.ExecuteReader();
            tabela.Load(rezultat);

            for (int i = 0; i < tabela.Rows.Count; i++)
            {
                string s0 = "       ";
                string s1 = (tabela.Rows[i].ItemArray[0].ToString() + razmak).Substring(0, 20);
                string s2 = (tabela.Rows[i].ItemArray[1].ToString() + razmak).Substring(0, 20);
                string s3 = (tabela.Rows[i].ItemArray[2].ToString() + razmak).Substring(0, 20);

                string s4 = (tabela.Rows[i].ItemArray[3].ToString() + razmak).Substring(0, 10).TrimEnd();
                string ceo = s0 + s1 + s2 + s3 + s0 + s4;
                listBox1.Items.Add(ceo);
            }
            rezultat.Close();
            konekcija.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            dateTimePicker1.ResetText();
            load();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            dateTimePicker1.ResetText();
            load();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            konekcija.ConnectionString = temp;
            konekcija.Open();
            komanda.Connection = konekcija;
            upit = "select * from autor where autorid=" + textBox1.Text;
            komanda.CommandText = upit;
            rezultat = komanda.ExecuteReader();
            tabela.Reset();
            tabela.Load(rezultat);
            int k = tabela.Rows.Count;
            if (k > 0)
            {
                MessageBox.Show("Sifra postojeca!");
            }
            else upit = "INSERT INTO `autor` (`AutorID`, `Ime`, `Prezime`, `DatumRodjenja`) VALUES ('" + textBox1.Text + "', '" + textBox2.Text + "', '" + textBox3.Text + "', '" + dateTimePicker1.Text + "')"; 
                komanda.CommandText = upit;
                rezultat = komanda.ExecuteReader();
                tabela.Reset();
                tabela.Load(rezultat);

                rezultat.Close();
                konekcija.Close();
                load();
            
        }

        private void listBox1_Click(object sender, EventArgs e)
        {
            int k = listBox1.SelectedIndex;
            textBox1.Text = tabela.Rows[k].ItemArray[0].ToString();
            textBox2.Text = tabela.Rows[k].ItemArray[1].ToString();
            textBox3.Text = tabela.Rows[k].ItemArray[2].ToString();
            dateTimePicker1.Text = tabela.Rows[k].ItemArray[3].ToString();
        }
    }
}
