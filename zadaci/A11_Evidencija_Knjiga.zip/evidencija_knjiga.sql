-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2023 at 04:44 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `evidencija_knjiga`
--

-- --------------------------------------------------------

--
-- Table structure for table `autor`
--

CREATE TABLE `autor` (
  `AutorID` int(11) NOT NULL,
  `Ime` varchar(45) DEFAULT NULL,
  `Prezime` varchar(45) DEFAULT NULL,
  `DatumRodjenja` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `autor`
--

INSERT INTO `autor` (`AutorID`, `Ime`, `Prezime`, `DatumRodjenja`) VALUES
(9001, 'Ivo', 'Andric', '1892-10-09'),
(9002, 'Andrej', 'Spakovski', '1948-06-21'),
(9003, 'Dzon', 'Tolkin', '1892-01-03'),
(9004, 'Stiven', 'King', '1947-09-21'),
(9005, 'Nora ', 'Roberts', '1950-10-10'),
(9006, 'Igor', 'Bergler', '1970-09-21'),
(9007, 'Lazar', 'Lazarevic', '1851-05-13'),
(9008, 'Volt', 'Dizni', '1966-12-15'),
(9009, 'Artur Konan', 'Dojl', '1859-05-22'),
(9010, 'K. Dz.', 'Doerti', '1958-09-15'),
(9011, 'Srdjan', 'Jerkovic', '1965-04-28'),
(9012, 'Ivo2', 'Andric2', '1892-10-10'),
(9013, 'Ivo3', 'Andric3', '2011-05-14'),
(9014, 'Ivo', 'Andric', '1892-10-09'),
(9069, 'Dzon', 'Tolkin', '1892-01-03'),
(9070, 'Nora 2', 'Roberts2', '1950-10-10');

-- --------------------------------------------------------

--
-- Table structure for table `autor_izdanje`
--

CREATE TABLE `autor_izdanje` (
  `KnjigaID` int(11) NOT NULL,
  `BrojIzdanja` int(11) NOT NULL,
  `AutorID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `autor_izdanje`
--

INSERT INTO `autor_izdanje` (`KnjigaID`, `BrojIzdanja`, `AutorID`) VALUES
(2001, 14, 9001),
(2002, 16, 9002),
(2003, 6, 9004),
(2003, 20, 9001),
(2004, 24, 9005),
(2004, 500, 9001),
(2005, 5, 9006),
(2006, 45, 9008),
(2007, 13, 9007),
(2008, 23, 9003),
(2009, 6, 9009),
(2010, 14, 9010),
(2011, 12, 9011);

-- --------------------------------------------------------

--
-- Table structure for table `formatknjige`
--

CREATE TABLE `formatknjige` (
  `FormatID` int(11) NOT NULL,
  `Oznaka` varchar(45) DEFAULT NULL,
  `Opis` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `formatknjige`
--

INSERT INTO `formatknjige` (`FormatID`, `Oznaka`, `Opis`) VALUES
(10111, 'A3', 'Opis formata A3'),
(10112, 'A1', 'Opis formata A1'),
(10113, 'A2', 'Opis formata A2'),
(10114, 'A4', 'Opis formata A4'),
(10115, 'A5', 'Opis formata A5'),
(10116, 'A6', 'Opis formata A6');

-- --------------------------------------------------------

--
-- Table structure for table `izdanje`
--

CREATE TABLE `izdanje` (
  `BrojIzdanja` int(11) NOT NULL,
  `KnjigaID` int(11) NOT NULL,
  `IzdavacID` int(11) DEFAULT NULL,
  `FormatID` int(11) DEFAULT NULL,
  `Cena` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `izdanjee`
--

CREATE TABLE `izdanjee` (
  `KnjigaID` int(11) NOT NULL,
  `BrojIzdanja` int(11) NOT NULL,
  `IzdavacID` int(11) DEFAULT NULL,
  `FormatID` int(11) DEFAULT NULL,
  `Cena` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `izdanjee`
--

INSERT INTO `izdanjee` (`KnjigaID`, `BrojIzdanja`, `IzdavacID`, `FormatID`, `Cena`) VALUES
(2001, 78, 1005, 10112, 795),
(2002, 6, 1006, 10113, 890),
(2003, 12, 1007, 10115, 2311),
(2004, 6, 1003, 10115, 290),
(2005, 15, 1002, 10114, 890),
(2006, 25, 1008, 10114, 435),
(2007, 8, 1005, 10111, 456),
(2008, 16, 1001, 10114, 1500),
(2009, 8, 1007, 10115, 950),
(2010, 5, 1010, 10113, 565),
(2011, 90, 1008, 10114, 790);

-- --------------------------------------------------------

--
-- Table structure for table `izdavac`
--

CREATE TABLE `izdavac` (
  `IzdavacID` int(11) NOT NULL,
  `Naziv` varchar(45) DEFAULT NULL,
  `Adresa` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `izdavac`
--

INSERT INTO `izdavac` (`IzdavacID`, `Naziv`, `Adresa`) VALUES
(1001, 'Laguna', 'Hajduk Veljkova 12'),
(1002, 'Carobna knjiga', 'Milutina Bojica 11'),
(1003, 'Darkwood', 'Kralja Petra I'),
(1004, 'Delfi', 'Vojvode Stepe 13'),
(1005, 'Odiseja', 'Milutina Milovanovica 87'),
(1006, 'Urban Reads', 'Nikole Tesle 10'),
(1007, 'Zlatno runo', 'Mihaila Pupina 54'),
(1008, 'Vulkan', 'Kralja Aleksandra Obrenovica 15'),
(1009, 'Prometej', 'Oktobarska 20'),
(1010, 'Zenit', 'Nadezde Petrovic 34');

-- --------------------------------------------------------

--
-- Table structure for table `kategorija`
--

CREATE TABLE `kategorija` (
  `KategorijaID` int(11) NOT NULL,
  `Naziv` varchar(45) DEFAULT NULL,
  `Opis` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kategorija`
--

INSERT INTO `kategorija` (`KategorijaID`, `Naziv`, `Opis`) VALUES
(111, 'Roman', 'Opis1'),
(222, 'Novele', 'Opis2'),
(333, 'Misterija', 'Opis3'),
(444, 'Horor', 'Opis4'),
(555, 'Fantastika', 'Opis5'),
(666, 'Pripovetka', 'Opis6'),
(777, 'Detektivski roman', 'Opis7'),
(888, 'Bajka', 'Opis8'),
(999, 'Triler', 'Opis9'),
(101010, 'Basna', 'Opis10');

-- --------------------------------------------------------

--
-- Table structure for table `knjiga`
--

CREATE TABLE `knjiga` (
  `KnjigaID` int(11) NOT NULL,
  `Naziv` varchar(45) DEFAULT NULL,
  `BrojStrana` int(11) DEFAULT NULL,
  `KategorijaID` int(11) DEFAULT NULL,
  `Komentar` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `knjiga`
--

INSERT INTO `knjiga` (`KnjigaID`, `Naziv`, `BrojStrana`, `KategorijaID`, `Komentar`) VALUES
(2001, 'Na Drini cuprija', 345, 111, 'Komentar: Istorijski roman'),
(2002, 'Saga o vescu: Poslednja zelja', 311, 555, 'Komentar: Saga o vescu'),
(2003, 'Isijavanje', 447, 444, 'Komentar: Odlicna knjiga'),
(2004, 'Savrsen komsija', 256, 111, 'Komentar: Ljubavni roman'),
(2005, 'Abrahamov testament', 495, 333, 'Komentar:Bas dobra knjiga'),
(2006, 'Tri praseta', 63, 888, 'Komentar: Za malu decu'),
(2007, 'Prvi put s ocem na jutrenje', 20, 666, 'Komentar: lepa pripovetka'),
(2008, 'Gospodar prstenova', 659, 555, 'Komentar: Vrlo lepa knjiga'),
(2009, 'Serlok Holms', 245, 777, 'Komentar: Detektivksa knjiga bas lepa'),
(2010, 'Nocna skola', 421, 999, 'Komentar: Odlican triler'),
(2011, 'Kornjaca i zec ', 56, 101010, 'Komentar: Basna za decu');

-- --------------------------------------------------------

--
-- Table structure for table `zaposleni`
--

CREATE TABLE `zaposleni` (
  `Ime` varchar(45) DEFAULT NULL,
  `Prezime` varchar(45) DEFAULT NULL,
  `Funkcija` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `autor`
--
ALTER TABLE `autor`
  ADD PRIMARY KEY (`AutorID`);

--
-- Indexes for table `autor_izdanje`
--
ALTER TABLE `autor_izdanje`
  ADD PRIMARY KEY (`KnjigaID`,`BrojIzdanja`,`AutorID`),
  ADD KEY `AutorID` (`AutorID`);

--
-- Indexes for table `formatknjige`
--
ALTER TABLE `formatknjige`
  ADD PRIMARY KEY (`FormatID`);

--
-- Indexes for table `izdanje`
--
ALTER TABLE `izdanje`
  ADD PRIMARY KEY (`BrojIzdanja`),
  ADD KEY `KnjigaID` (`KnjigaID`);

--
-- Indexes for table `izdanjee`
--
ALTER TABLE `izdanjee`
  ADD PRIMARY KEY (`KnjigaID`,`BrojIzdanja`),
  ADD KEY `IzdavacID` (`IzdavacID`),
  ADD KEY `FormatID` (`FormatID`);

--
-- Indexes for table `izdavac`
--
ALTER TABLE `izdavac`
  ADD PRIMARY KEY (`IzdavacID`);

--
-- Indexes for table `kategorija`
--
ALTER TABLE `kategorija`
  ADD PRIMARY KEY (`KategorijaID`);

--
-- Indexes for table `knjiga`
--
ALTER TABLE `knjiga`
  ADD PRIMARY KEY (`KnjigaID`),
  ADD KEY `KategorijaID` (`KategorijaID`);

--
-- Indexes for table `zaposleni`
--
ALTER TABLE `zaposleni`
  ADD PRIMARY KEY (`Funkcija`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `autor_izdanje`
--
ALTER TABLE `autor_izdanje`
  ADD CONSTRAINT `autor_izdanje_ibfk_1` FOREIGN KEY (`KnjigaID`) REFERENCES `knjiga` (`KnjigaID`),
  ADD CONSTRAINT `autor_izdanje_ibfk_2` FOREIGN KEY (`AutorID`) REFERENCES `autor` (`AutorID`),
  ADD CONSTRAINT `autor_izdanje_ibfk_3` FOREIGN KEY (`KnjigaID`) REFERENCES `knjiga` (`KnjigaID`);

--
-- Constraints for table `izdanje`
--
ALTER TABLE `izdanje`
  ADD CONSTRAINT `izdanje_ibfk_1` FOREIGN KEY (`BrojIzdanja`) REFERENCES `knjiga` (`KnjigaID`),
  ADD CONSTRAINT `izdanje_ibfk_2` FOREIGN KEY (`KnjigaID`) REFERENCES `knjiga` (`KnjigaID`);

--
-- Constraints for table `izdanjee`
--
ALTER TABLE `izdanjee`
  ADD CONSTRAINT `izdanjee_ibfk_1` FOREIGN KEY (`KnjigaID`) REFERENCES `knjiga` (`KnjigaID`),
  ADD CONSTRAINT `izdanjee_ibfk_2` FOREIGN KEY (`IzdavacID`) REFERENCES `izdavac` (`IzdavacID`),
  ADD CONSTRAINT `izdanjee_ibfk_3` FOREIGN KEY (`FormatID`) REFERENCES `formatknjige` (`FormatID`);

--
-- Constraints for table `knjiga`
--
ALTER TABLE `knjiga`
  ADD CONSTRAINT `knjiga_ibfk_1` FOREIGN KEY (`KategorijaID`) REFERENCES `kategorija` (`KategorijaID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
