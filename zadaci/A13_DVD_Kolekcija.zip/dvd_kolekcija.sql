-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2023 at 05:05 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dvd_kolekcija`
--

-- --------------------------------------------------------

--
-- Table structure for table `film`
--

CREATE TABLE `film` (
  `FilmID` int(11) NOT NULL,
  `Naziv` varchar(20) DEFAULT NULL,
  `DatumIzlaska` date DEFAULT NULL,
  `Trajanje` decimal(10,0) DEFAULT NULL,
  `ZanrID` int(11) DEFAULT NULL,
  `OpisRadnje` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `film`
--

INSERT INTO `film` (`FilmID`, `Naziv`, `DatumIzlaska`, `Trajanje`, `ZanrID`, `OpisRadnje`) VALUES
(1010, 'Zoki uboica', '2023-01-14', '2', 1001, 'Zoki kida sve pred s'),
(1011, 'Cone Vik', '2022-07-12', '1', 1002, 'Cone je jak momak i '),
(1012, 'Sova iz tame', '2021-07-02', '1', 1003, 'Sova iz tame vlada s'),
(1013, 'Velja padavicar', '2016-05-22', '2', 1004, 'Velja je jako kul li'),
(1014, 'Brza kola', '2014-10-10', '1', 1005, 'Trkanje sa akcijom'),
(1015, 'Detektiv Pipke', '2019-10-02', '1', 1006, 'Detektiv sa odlicnim'),
(1016, 'Vulic golden boy', '2012-05-15', '2', 1007, 'Vulic ima zadatak da'),
(1017, 'Novak pise', '2023-02-01', '1', 1008, 'Novak pise pismo nek'),
(1018, 'Pad sa mosta', '2013-02-01', '3', 1009, 'Mladi par odluci da '),
(1019, 'Tihi hodac', '2017-07-21', '2', 1010, 'Hodack koji tiho hod');

-- --------------------------------------------------------

--
-- Table structure for table `film_nagrada`
--

CREATE TABLE `film_nagrada` (
  `FilmID` int(11) NOT NULL,
  `NagradaID` int(11) DEFAULT NULL,
  `GodinaDodele` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `film_nagrada`
--

INSERT INTO `film_nagrada` (`FilmID`, `NagradaID`, `GodinaDodele`) VALUES
(11, 1, 2010),
(12, 2, 2011),
(13, 3, 2012),
(14, 4, 2013),
(15, 5, 2014),
(16, 6, 2015),
(17, 7, 2016),
(18, 8, 2017),
(19, 9, 2018),
(20, 10, 2019);

-- --------------------------------------------------------

--
-- Table structure for table `glumac`
--

CREATE TABLE `glumac` (
  `GlumacID` int(11) NOT NULL,
  `Ime` varchar(20) DEFAULT NULL,
  `Prezime` varchar(20) DEFAULT NULL,
  `DatumRodjenja` date DEFAULT NULL,
  `MestoRodjenja` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `glumac`
--

INSERT INTO `glumac` (`GlumacID`, `Ime`, `Prezime`, `DatumRodjenja`, `MestoRodjenja`) VALUES
(1, 'Aca', 'Acic', '1997-06-15', 'Arandjelovac'),
(2, 'Bosko', 'Boskic', '1987-05-20', 'Bor'),
(3, 'Veljko', 'Veljic', '2000-01-01', 'Valjevo'),
(4, 'Goran', 'Gogic', '1950-03-05', 'Aleksinac'),
(5, 'Dritan', 'Dajkovic', '1965-02-12', 'Donji Milanovac'),
(6, 'Djordje', 'Djinic', '2004-04-14', 'Djakovica'),
(7, 'Erik', 'Estvic', '1933-08-11', 'Odzaci'),
(8, 'Zivko', 'Zivanovic', '2005-12-11', 'Pirot'),
(9, 'Ivan', 'Ivanovic', '1986-09-25', 'Pristina'),
(10, 'Jovan', 'Jovanovic', '1999-09-25', 'Kragujevac');

-- --------------------------------------------------------

--
-- Table structure for table `nagrada`
--

CREATE TABLE `nagrada` (
  `NagradaID` int(11) NOT NULL,
  `Naziv` varchar(20) DEFAULT NULL,
  `GodinaPocetka` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nagrada`
--

INSERT INTO `nagrada` (`NagradaID`, `Naziv`, `GodinaPocetka`) VALUES
(1, 'Aleksej', 2000),
(2, 'Borina nagrada', 2001),
(3, 'Velington', 2002),
(4, 'Godisnja', 2003),
(5, 'Danska', 2004),
(6, 'Djeramska', 1955),
(7, 'Emirova', 1956),
(8, 'Zikina', 1957),
(9, 'Zoricina', 1958),
(10, 'Igmanska', 1959);

-- --------------------------------------------------------

--
-- Table structure for table `producent`
--

CREATE TABLE `producent` (
  `ProducentID` int(11) NOT NULL,
  `Ime` varchar(20) DEFAULT NULL,
  `Email` varchar(20) DEFAULT NULL,
  `WebSite` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `producent`
--

INSERT INTO `producent` (`ProducentID`, `Ime`, `Email`, `WebSite`) VALUES
(100, 'Andrija22', 'andrija22.andrija@gm', 'www.andrijaandrija.c'),
(101, 'Bora', 'bora.bora@gmail.com', 'www.borabora.com'),
(102, 'Veljko', 'veljko2.veljko@gmail', 'www.veljkoveljko.com'),
(103, 'Goran', 'goran.goran@gmail.co', 'www.gorangoran.com'),
(104, 'Dragan', 'dragan.dragan@gmail.', 'www.dragandragan.com'),
(105, 'Djordje taskovic', 'tasko@microsoft.rs', 'www.djordjedjordje.c'),
(106, 'Ema', 'ema.ema@gmail.com', 'www.emaema.com'),
(107, 'Zika', 'zika.zika@gmail.com', 'www.zikazika.com'),
(108, 'Zoran', 'zoran.zoran@gmail.co', 'www.zoranzoran.com'),
(109, 'Ivica', 'ivica.ivica@gmail.co', 'www.ivicaivica.com');

-- --------------------------------------------------------

--
-- Table structure for table `producirao`
--

CREATE TABLE `producirao` (
  `FilmID` int(11) NOT NULL,
  `ProducentID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `producirao`
--

INSERT INTO `producirao` (`FilmID`, `ProducentID`) VALUES
(201, 100),
(202, 101),
(203, 102),
(204, 103),
(205, 104),
(206, 105),
(207, 106),
(208, 107),
(209, 108),
(210, 109);

-- --------------------------------------------------------

--
-- Table structure for table `tip_uloge`
--

CREATE TABLE `tip_uloge` (
  `TipUlogeID` int(11) NOT NULL,
  `Tip` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tip_uloge`
--

INSERT INTO `tip_uloge` (`TipUlogeID`, `Tip`) VALUES
(11, 'Glavni glumac'),
(12, 'Sporedni glumac'),
(13, 'Statista'),
(14, 'Glavna glumica'),
(15, 'Sporedna glumica'),
(16, 'Statista'),
(17, 'Glavni glumac'),
(18, 'Sporedni glumac'),
(19, 'Statista'),
(20, 'Statista');

-- --------------------------------------------------------

--
-- Table structure for table `uloga`
--

CREATE TABLE `uloga` (
  `FilmID` int(11) NOT NULL,
  `GlumacID` int(11) NOT NULL,
  `TipUlogeID` int(11) DEFAULT NULL,
  `ImeLika` varchar(11) NOT NULL,
  `OpisLika` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `uloga`
--

INSERT INTO `uloga` (`FilmID`, `GlumacID`, `TipUlogeID`, `ImeLika`, `OpisLika`) VALUES
(1010, 1, 11, 'Alimpije', 'Veliki strasan covek'),
(1011, 2, 12, 'Sima', 'Mali pomocnik'),
(1012, 3, 13, 'Kira', 'Slabasni mali cika'),
(1013, 4, 14, 'Ana', 'Apotekarka '),
(1014, 5, 15, 'Mileva', 'Lepa policajka'),
(1015, 6, 16, 'Simonida', 'Prodavacica guma'),
(1016, 7, 17, 'Neca', 'Neca pereca'),
(1017, 8, 18, 'Palistar', 'Primac pisma '),
(1018, 9, 19, 'Pavle', 'Drugar iz kraja'),
(1019, 10, 20, 'Sasa', 'Prodavac oruzja');

-- --------------------------------------------------------

--
-- Table structure for table `zanr`
--

CREATE TABLE `zanr` (
  `ZanrID` int(11) NOT NULL,
  `NazivZanra` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zanr`
--

INSERT INTO `zanr` (`ZanrID`, `NazivZanra`) VALUES
(1001, 'Horor'),
(1002, 'Akcija'),
(1003, 'Horor'),
(1004, 'Komedija'),
(1005, 'Akcija'),
(1006, 'Triler'),
(1007, 'Triler'),
(1008, 'Komedija'),
(1009, 'Dram'),
(1010, 'Krimi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `film`
--
ALTER TABLE `film`
  ADD PRIMARY KEY (`FilmID`),
  ADD KEY `ZanrID` (`ZanrID`);

--
-- Indexes for table `film_nagrada`
--
ALTER TABLE `film_nagrada`
  ADD PRIMARY KEY (`FilmID`),
  ADD KEY `NagradaID` (`NagradaID`);

--
-- Indexes for table `glumac`
--
ALTER TABLE `glumac`
  ADD PRIMARY KEY (`GlumacID`);

--
-- Indexes for table `nagrada`
--
ALTER TABLE `nagrada`
  ADD PRIMARY KEY (`NagradaID`);

--
-- Indexes for table `producent`
--
ALTER TABLE `producent`
  ADD PRIMARY KEY (`ProducentID`);

--
-- Indexes for table `producirao`
--
ALTER TABLE `producirao`
  ADD PRIMARY KEY (`FilmID`),
  ADD KEY `ProducentID` (`ProducentID`);

--
-- Indexes for table `tip_uloge`
--
ALTER TABLE `tip_uloge`
  ADD PRIMARY KEY (`TipUlogeID`);

--
-- Indexes for table `uloga`
--
ALTER TABLE `uloga`
  ADD PRIMARY KEY (`FilmID`,`GlumacID`,`ImeLika`),
  ADD KEY `TipUlogeID` (`TipUlogeID`),
  ADD KEY `GlumacID` (`GlumacID`);

--
-- Indexes for table `zanr`
--
ALTER TABLE `zanr`
  ADD PRIMARY KEY (`ZanrID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `film`
--
ALTER TABLE `film`
  ADD CONSTRAINT `film_ibfk_1` FOREIGN KEY (`ZanrID`) REFERENCES `zanr` (`ZanrID`);

--
-- Constraints for table `film_nagrada`
--
ALTER TABLE `film_nagrada`
  ADD CONSTRAINT `film_nagrada_ibfk_1` FOREIGN KEY (`NagradaID`) REFERENCES `nagrada` (`NagradaID`);

--
-- Constraints for table `producirao`
--
ALTER TABLE `producirao`
  ADD CONSTRAINT `producirao_ibfk_1` FOREIGN KEY (`ProducentID`) REFERENCES `producent` (`ProducentID`);

--
-- Constraints for table `uloga`
--
ALTER TABLE `uloga`
  ADD CONSTRAINT `uloga_ibfk_1` FOREIGN KEY (`FilmID`) REFERENCES `film` (`FilmID`),
  ADD CONSTRAINT `uloga_ibfk_2` FOREIGN KEY (`FilmID`) REFERENCES `film` (`FilmID`),
  ADD CONSTRAINT `uloga_ibfk_3` FOREIGN KEY (`TipUlogeID`) REFERENCES `tip_uloge` (`TipUlogeID`),
  ADD CONSTRAINT `uloga_ibfk_4` FOREIGN KEY (`GlumacID`) REFERENCES `glumac` (`GlumacID`),
  ADD CONSTRAINT `uloga_ibfk_5` FOREIGN KEY (`FilmID`) REFERENCES `film` (`FilmID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
