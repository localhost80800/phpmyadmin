-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 01, 2023 at 11:23 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ribolovacko_drustvo`
--

-- --------------------------------------------------------

--
-- Table structure for table `grad`
--

CREATE TABLE `grad` (
  `Grad` varchar(35) DEFAULT NULL,
  `PozivniBroj` int(20) DEFAULT NULL,
  `PostanskiBroj` int(11) DEFAULT NULL,
  `BrojStanovnika` int(11) DEFAULT NULL,
  `GradID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `grad`
--

INSERT INTO `grad` (`Grad`, `PozivniBroj`, `PostanskiBroj`, `BrojStanovnika`, `GradID`) VALUES
('Arandjelovac', 3471936, 34300, 44500, 1),
('Beograd - Borca', 113325871, 11211, 46086, 2),
('Zrenjanin', 23593413, 350902, 74459, 3),
('Kac', 21854293, 21241, 11740, 4),
('Ruma', 22600686, 22400, 30076, 5),
('Novi Itebej', 232827900, 23236, 1315, 6),
('Zitiste', 23593454, 23210, 2903, 7),
('Zrenjanin', 23593413, 350902, 74459, 8),
('Banatsko Veliko Selo', 230451400, 23312, 3034, 9),
('Satrinci', 22543425, 22328, 399, 10);

-- --------------------------------------------------------

--
-- Table structure for table `jezero`
--

CREATE TABLE `jezero` (
  `Naziv` varchar(35) DEFAULT NULL,
  `BrojLokacija` varchar(35) DEFAULT NULL,
  `JezeroID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jezero`
--

INSERT INTO `jezero` (`Naziv`, `BrojLokacija`, `JezeroID`) VALUES
('Garasko jezero', 'Ima 5 lokacija', 1),
('Mika alas', 'Jezero u Borci i ima 4 lokacije', 2),
('Jezero Cepel', 'Ima 4 lokacije', 3),
('Jezero Crni Vir', 'Ima 15 lokacija', 4),
('Jezero Dobrodol', 'Ima 2 lokacije', 5),
('Jezero Figura', 'Ima 4 lokacije', 6),
('Jezero Grgeč', 'Ima 3 lokacije', 7),
('Jezero Joca', 'Ima 6 lokacija', 8),
('Jezero Laguna', 'Ima 1 lokaciju', 9),
('Jezero Medjes', 'Ima 7 lokacija', 10);

-- --------------------------------------------------------

--
-- Table structure for table `lokacija`
--

CREATE TABLE `lokacija` (
  `JezeroID` int(11) NOT NULL,
  `RbrLokacije` int(11) NOT NULL,
  `Naziv` varchar(35) DEFAULT NULL,
  `Beleske` varchar(10000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lokacija`
--

INSERT INTO `lokacija` (`JezeroID`, `RbrLokacije`, `Naziv`, `Beleske`) VALUES
(1, 1, 'Garasko jezero - Arandjelovac', 'Jedno od lepsih jezera u Srbiji je i Garasko jezero. Nalazi se u blizini Arandjelovca, okruzeno prelepim predelima tik ispod Bukulje. Velika lovna povrsina ne tako bogata ribom kao sto se prica. Najvise je smudja, koji se peca svakodnevno i veoma uspesno na zivi mamac. Sarana i soma ima ali ulovi su retki i uglavnom su to primerci preko 10 kg. Skoro izvadjeni sarani od 17kg i 26 kg (14.06.2012.). Soma ima dosta ali su tromi i ne tako aktivni. Prosle sezone je izvadjen som tezine preko 50 kg. \r\n\r\nPostavljanje satora je dozvoljeno, koriscenje rc brodica za prihranu takodje. Postoji mogucnost i manjim gumenim camcima prihraniti mesto. Po novom pravilniku je dozvoljeni ulov ogranicen na 5 kg ribe, ukoliko saran pređe kao jedinka tu težinu onda je dozvoljen ulov istog do maksimalne težine od 10kg. Smudj je ogranicen na 5 kg kao i stuka i takvi primerci koji prelaze tu tezinu se vracaju nazad u vodu.'),
(2, 2, 'Mika alas', '  Jezero Mika Alas obiluje krupnom ribom pa je stoga raj za ribolovce. Na celom jezeru se peca sa platformi na kojima se vec nalazi sak kako ne bi dolazilo do oštećenja same ribe koja se peca. Na ulazu u jezero imate obezbeđen parking za vozila koja tamo moraju da budu parkirana posle odlaganja i istovaranja opreme (optremu dovezete do platforme koju ste predhodno rezervisali). '),
(3, 3, 'Jezero Cepel , Zrenjanin', 'Jezero Cepel je nekoliko dugotrajnih sezona bilo pod zabranom ribolova. Relativno skoro je konaCno uspostavljen rezim slobodnog pecanja na ovoj vodi. KSR Banat je formirao klubsko ribolovacko kampiraliste, pre svega kolega iz saranskog ribolova koji su jasno opredeljeni ka ribolovackom geslu “Uhvati i pusti”.'),
(4, 4, 'Jezero Crni Vir, Kac', 'Jezero Crni Vir ima 15 mesta za rekreativni ribolov, a za sarandzijska takmicenja ima 10 mesta. Mala voda ce imati deset mesta za pecanje. Pecanje na glavnom jezeru je dozvoljeno parabolicima,stek stapom i method feeder tehnikom. Glavno jezero je predvidjeno za sarandžije sa parabolik stapovima, za pecarose sa stek stapovima i za ljubitelje feeder tehnike. Oni koji zele da pecaju mec ili drugom plovkaroškom tehnikom na raspolaganju je mala voda.'),
(5, 5, 'Jezero Dobrodol, Ruma', 'Jezero \r\nDobrodol\r\n nalazi se kod istoimenog sela, na juznim obroncima Fruske Gore, otprilike u sredini trougla cija su temena Irig, Ruma i Indjija. U pitanju je vestacko jezero, nastalo podizanjem brane na Dobrodolskom potoku. Jezero cesto posecuju ribolovci, a leti je u njemu moguće \r\nkupanje'),
(6, 6, 'Jezero Figura, Novi Itebej', 'Jezero Figura, Novi Itebej nalazi se na 30tak kilometara od Zrenjanina. Jezero odrzava Udruzenje sportskih ribolovaca Figura, Prosecna dubina jezera je oko 1.5m. Dana 5. aprila na jezeru u Novom Itebeju sprovedeno je poribljavanje ribnjaka u organizaciji clanova Udruzenja sportskih ribolovaca “Figura”. U vodu je pusteno 600kg šarana od 2-5kg, 100kg amura 0.2-1.5kg, i 50kg karasa.'),
(7, 7, 'Jezero Grgec – Zitiste', 'Zitište moze da pohvali sa novim sportskim ribnjakom, a mestani ovog mesta veruju da je ova investicija dobra i da ce zaista sluziti nameni.'),
(8, 8, 'Jezero Joca, Zrenjanin', 'Raj za pecarose, prostire se na povrsini od oko 500 ha. Nalazi se kod sela Belo Blato u sklopu kompleksa Ribarskog gazdinstva „Ečka“. Jezero je „Catch and Release“ tipa, pa se ulov nakon fotografisanja vraca u vodu. U jezeru ima svih vrsta ribe, a najvise stuke i sarana.'),
(9, 9, 'Jezero Laguna – Banatsko Veliko Sel', 'Jezero Laguna, revir koji se prostire se na 2 – 2,5 ha, poribljen saranskom ribom – autohtoni saranima tzv. „vretenarima“ koji su ostali jos od ranije, dok je revir bio bara.'),
(10, 10, 'Jezero Medjes, Satrinci', 'Jezero Medjes, Satrinci\r\nJezero Medjes, poznatije kao Satrinacko jezero, nastalo je akumulacijom vode nakon podizanja brane na potoku Međes za potrebe navodnjavanja nekada velikog i poznatog vocnjaka. Nalazi se na juznoj padini Fruske gore u blizini mesta Satrinci i nedaleko od Iriga.');

-- --------------------------------------------------------

--
-- Table structure for table `pecaros`
--

CREATE TABLE `pecaros` (
  `Ime` varchar(15) DEFAULT NULL,
  `Prezime` varchar(15) DEFAULT NULL,
  `Adresa` varchar(35) DEFAULT NULL,
  `Telefon` varchar(100) DEFAULT NULL,
  `GradID` int(11) NOT NULL,
  `PecarosID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pecaros`
--

INSERT INTO `pecaros` (`Ime`, `Prezime`, `Adresa`, `Telefon`, `GradID`, `PecarosID`) VALUES
('Jovan2', 'Mijovic', 'Negde u Belosavcima', '021-489-26-96', 7, 1),
('Milan', 'Milanovic', 'Kralja Petra prvog', '067-374-832', 2, 2),
('Petar', 'Peric', 'Milana Milanovica 34', '065-453-212', 5, 3),
('Petra', 'Jovic', 'Milutina Milankovica 36', '062-453-70', 4, 4),
('Jovan', 'Milankovic', 'Trg oslobodjenja 6', '066-334-452', 6, 5),
('Mladen', 'Dimitrijevic', 'Vuka Karadzica 18', '064-549-866', 8, 6),
('Tadija', 'Krstic', 'Nusiceva 11', '060-630-050', 7, 7),
('Perica', 'Mladenovic', 'Kralja Petra prvog 28', '068-473-860', 10, 8),
('Dunja', 'Markovic', 'Nusiceva 84', '063-405-607', 9, 9),
('Nikola', 'Mirkovic', 'Kralja Petra prvog 43', '065-903-402', 3, 10);

-- --------------------------------------------------------

--
-- Table structure for table `ulov`
--

CREATE TABLE `ulov` (
  `PecarosID` int(11) NOT NULL,
  `RbrUlova` int(11) NOT NULL,
  `Vreme` time NOT NULL,
  `VrstaID` int(11) NOT NULL,
  `Tezina` varchar(10) DEFAULT NULL,
  `JezeroID` int(11) NOT NULL,
  `RbrLokacije` int(11) NOT NULL,
  `Datum` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ulov`
--

INSERT INTO `ulov` (`PecarosID`, `RbrUlova`, `Vreme`, `VrstaID`, `Tezina`, `JezeroID`, `RbrLokacije`, `Datum`) VALUES
(1, 4, '10:19:06', 3, '1.2 kg', 4, 4, '2020-05-03'),
(1, 69, '19:28:29', 8, '500kg', 25, 44, '2023-03-01'),
(2, 3, '16:33:14', 8, '7 kg', 3, 3, '2019-06-06'),
(3, 4, '12:07:13', 9, '8kg', 2, 2, '2019-04-22'),
(4, 5, '12:07:13', 10, '300 g', 5, 5, '2019-03-15'),
(5, 2, '09:19:13', 1, '35 kg', 10, 10, '2020-06-01'),
(6, 7, '19:09:19', 4, '1.4 kg', 6, 6, '2020-01-17'),
(7, 1, '13:29:14', 2, '145 kg', 7, 7, '2019-04-11'),
(8, 5, '19:13:42', 6, '7.6 kg', 8, 8, '2020-05-10'),
(9, 16, '20:11:19', 5, '3.5 kg', 1, 1, '2022-05-21'),
(10, 9, '20:24:31', 7, '10.9 kg', 9, 9, '2019-05-31');

-- --------------------------------------------------------

--
-- Table structure for table `vrsta_ribe`
--

CREATE TABLE `vrsta_ribe` (
  `Naziv` varchar(25) DEFAULT NULL,
  `Opis` varchar(10000) DEFAULT NULL,
  `VrstaID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vrsta_ribe`
--

INSERT INTO `vrsta_ribe` (`Naziv`, `Opis`, `VrstaID`) VALUES
('Šaran', 'Šaran je slatkovodna riba sa koštanim skeletom', 1),
('Som', 'Som je jedna od najvecih slatkovodnih riba', 2),
('Babuška', 'Babuška je slatkovodna riba veoma prilagodljive prirode', 3),
('Karaš', 'Karaš je slatkovodna riba koja zivi uglavno u mirnim, jako zatravljenim ravnicarskim vodama sa muljevitim dnom', 4),
('Evropska jegulja', 'Evropska jegulja je riba iz porodice jegulja', 5),
('Linjak', 'Linjak,linj ili linis, je riba iz porodice šarana. Naseljava naše vode kao i vode skoro cele Evrope, a prenet je i u Severnu Ameriku...', 6),
('Smudj', 'Smudj je slatkovodna riba iz familije grgeca Percidae', 7),
('Beli amur', 'Beli amur je slatkovodna riba sa koštanim skeletom i istovremeno pripada i mekoperkama i porodici šarana', 8),
('Balavac', 'Balavac zrakpoerka je iz reda PericiFormes. Vestacki je uvedena na podrucje Velikihjezera u Severnoj Americi, i prisustvo ribe je znacajno ostetilo lokalni ekosistem', 9),
('Belica', 'Belica je slatkovodna riba koja pripada familiji Cyprinidae. Lokalni nazivi: najlonka, belka, kosalj, bela riba Maks', 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `grad`
--
ALTER TABLE `grad`
  ADD PRIMARY KEY (`GradID`);

--
-- Indexes for table `jezero`
--
ALTER TABLE `jezero`
  ADD PRIMARY KEY (`JezeroID`);

--
-- Indexes for table `lokacija`
--
ALTER TABLE `lokacija`
  ADD PRIMARY KEY (`JezeroID`,`RbrLokacije`);

--
-- Indexes for table `pecaros`
--
ALTER TABLE `pecaros`
  ADD PRIMARY KEY (`PecarosID`),
  ADD KEY `GradID` (`GradID`);

--
-- Indexes for table `ulov`
--
ALTER TABLE `ulov`
  ADD PRIMARY KEY (`PecarosID`,`RbrUlova`),
  ADD KEY `VrstaID` (`VrstaID`),
  ADD KEY `JezeroID` (`JezeroID`);

--
-- Indexes for table `vrsta_ribe`
--
ALTER TABLE `vrsta_ribe`
  ADD PRIMARY KEY (`VrstaID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `pecaros`
--
ALTER TABLE `pecaros`
  ADD CONSTRAINT `pecaros_ibfk_1` FOREIGN KEY (`GradID`) REFERENCES `grad` (`GradID`);

--
-- Constraints for table `ulov`
--
ALTER TABLE `ulov`
  ADD CONSTRAINT `ulov_ibfk_1` FOREIGN KEY (`VrstaID`) REFERENCES `vrsta_ribe` (`VrstaID`),
  ADD CONSTRAINT `ulov_ibfk_2` FOREIGN KEY (`PecarosID`) REFERENCES `pecaros` (`PecarosID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
