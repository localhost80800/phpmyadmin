﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySqlConnector;

namespace A01_Biblioteka
{
    public partial class Form1 : Form
    {
        MySqlConnection konekcija = new MySqlConnection();
        MySqlCommand komanda = new MySqlCommand();
        DataTable tabela = new DataTable();
        MySqlDataReader rezultat;
        string upit;
        string temp = "server=localhost;user id=root;password=asd123;database=biblioteka";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();

            konekcija.ConnectionString = temp;
            konekcija.Open();
            komanda.Connection = konekcija;
            upit = "select * from citalac";
            komanda.CommandText = upit;
            rezultat = komanda.ExecuteReader();
            tabela.Reset();
            tabela.Load(rezultat);
            int k = tabela.Rows.Count;

            for (int i = 0; i < k; i++)
            {
                string s1 = tabela.Rows[i].ItemArray[0].ToString();
                string s2 = tabela.Rows[i].ItemArray[1].ToString();
                string s3 = tabela.Rows[i].ItemArray[2].ToString();
                string s4 = tabela.Rows[i].ItemArray[3].ToString();
                string s5 = tabela.Rows[i].ItemArray[4].ToString();
                string s6 = s1 + " - " + s3 + " " + s4;
                comboBox1.Items.Add(s6);
                comboBox2.Items.Add(s1);

                string[] red = { s1, s2, s3, s4, s5 };
                var ubaci = new ListViewItem(red);
                listView1.Items.Add(ubaci);



            }
            rezultat.Close();
            konekcija.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e) // OVAJ DEO UGASITE NA MATURI VAM NE TREBA KAKO OCETE 
        {
            if (listView1.SelectedItems.Count > 0)
            {
                textBox1.Text = listView1.SelectedItems[0].SubItems[0].Text;
                textBox2.Text = listView1.SelectedItems[0].SubItems[1].Text;
                textBox3.Text = listView1.SelectedItems[0].SubItems[2].Text;
                textBox4.Text = listView1.SelectedItems[0].SubItems[3].Text;
                textBox5.Text = listView1.SelectedItems[0].SubItems[4].Text;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox2.SelectedIndex = comboBox1.SelectedIndex;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            konekcija.ConnectionString = temp;
            konekcija.Open();
            komanda.Connection = konekcija;
            upit = "select * from citalac where citalacid=" + textBox1.Text;
            komanda.CommandText = upit;
            rezultat = komanda.ExecuteReader();
            tabela.Reset();
            tabela.Load(rezultat);
            int k = tabela.Rows.Count;
            if (k > 0)
            {
                MessageBox.Show("Šifra je zauzeta, pokušajte neku drugu!");
            }
            else { 
                upit = "insert into citalac(citalacid,matbr,ime,prezime,adresa) values ";
                upit += "(" + textBox1.Text + "," + textBox2.Text + ",'" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "')";
                MessageBox.Show("Uspešan upis");
            }

            komanda.CommandText = upit;
            rezultat = komanda.ExecuteReader();
            tabela.Reset();
            tabela.Load(rezultat);

            rezultat.Close();
            konekcija.Close();

            listView1.Items.Clear();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();

            konekcija.ConnectionString = temp;
            konekcija.Open();
            komanda.Connection = konekcija;
            upit = "select * from citalac";
            komanda.CommandText = upit;
            rezultat = komanda.ExecuteReader();
            tabela.Reset();
            tabela.Load(rezultat);
            k = tabela.Rows.Count;

            for (int i = 0; i < k; i++)
            {
                string s1 = tabela.Rows[i].ItemArray[0].ToString();
                string s2 = tabela.Rows[i].ItemArray[1].ToString();
                string s3 = tabela.Rows[i].ItemArray[2].ToString();
                string s4 = tabela.Rows[i].ItemArray[3].ToString();
                string s5 = tabela.Rows[i].ItemArray[4].ToString();
                string s6 = s1 + " - " + s3 + " " + s4;
                comboBox1.Items.Add(s6);
                comboBox2.Items.Add(s1);

                string[] red = { s1, s2, s3, s4, s5 };
                var ubaci = new ListViewItem(red);
                listView1.Items.Add(ubaci);



            }
            rezultat.Close();
            konekcija.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DataTable tabela2 = new DataTable();
            chart1.Titles.Clear();
            chart1.Titles.Add("Grafik vraćenih i nevraćenih knjiga");

            konekcija.ConnectionString = temp;
            konekcija.Open();
            komanda.Connection = konekcija;
            upit = "SELECT concat(citalac.ime,' ',citalac.prezime) as Citalac,year(nacitanju.datumuzimanja) as Godina,COUNT(nacitanju.citalacid) as " +
                "'Broj iznajmljivanja',(COUNT(nacitanju.datumuzimanja)-COUNT(nacitanju.datumvracanja)) as 'Nije vracen' from nacitanju INNER JOIN citalac " +
                "on citalac.citalacid=nacitanju.citalacid where nacitanju.citalacid="+comboBox2.Text+ " and year(nacitanju.datumuzimanja)>=" + numericUpDown1.Value+ " " +
                "and year(nacitanju.datumuzimanja)<=" + numericUpDown2.Value+" group by Godina;";

            komanda.CommandText = upit;
            rezultat = komanda.ExecuteReader();
            tabela2.Load(rezultat);

            dataGridView1.DataSource = tabela2;
            chart1.DataSource = tabela2;
            chart1.ChartAreas[0].AxisX.Title = "Godina";
            chart1.ChartAreas[0].AxisY.Title = "Broj iznajmljivanja";
            chart1.Series["Ukupno knjiga"].XValueMember = "Godina";
            chart1.Series["Ukupno knjiga"].YValueMembers = "Broj iznajmljivanja";
            chart1.Series["Nije vraćeno"].XValueMember = "Godina";
            chart1.Series["Nije vraćeno"].YValueMembers = "Nije vracen";
            rezultat.Close();
            konekcija.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e) // AKO OCETE DA NE MORATE NA ENTER DA KLIKCETE ONDA PREMESTITE OVAJ KOD U TEXTBOX1_TEXTCHANGED MUNJICU
        {
            if (textBox1.Text != "")
            {
                listView1.SelectedItems.Clear();
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                for (int i = 0; i < listView1.Items.Count; i++)
                {
                    if (textBox1.Text == listView1.Items[i].SubItems[0].Text)
                    {
                        listView1.Items[i].Selected = true;
                        textBox2.Text = listView1.Items[i].SubItems[1].Text;
                        textBox3.Text = listView1.Items[i].SubItems[2].Text;
                        textBox4.Text = listView1.Items[i].SubItems[3].Text;
                        textBox5.Text = listView1.Items[i].SubItems[4].Text;
                    }
                }
            }
        }
    }
}
