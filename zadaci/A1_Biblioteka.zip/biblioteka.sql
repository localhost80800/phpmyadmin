-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 01, 2023 at 11:21 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `biblioteka`
--

-- --------------------------------------------------------

--
-- Table structure for table `autor`
--

CREATE TABLE `autor` (
  `autorid` int(11) NOT NULL,
  `ime` varchar(50) DEFAULT NULL,
  `prezime` varchar(50) DEFAULT NULL,
  `datumrodjenja` date DEFAULT NULL,
  `adresa` varchar(50) DEFAULT NULL,
  `zvanje` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `autor`
--

INSERT INTO `autor` (`autorid`, `ime`, `prezime`, `datumrodjenja`, `adresa`, `zvanje`) VALUES
(11, 'Aga', 'Agic', '2004-06-01', 'Mihajla Pupina 24', 'Ker'),
(22, 'Zika', 'Zikic', '2012-03-23', 'Draze Mihajlovica 34', 'Pasce'),
(33, 'Demiri', 'Dzajic', '2001-11-20', 'Velimira Kraisnika 42', 'Kezva'),
(44, 'Zika', 'Gajic', '2004-06-16', 'Koralovo 49', 'Pekar'),
(55, 'Zoran', 'Hujkic', '2000-09-26', 'Takovska 34', 'Poslasticar'),
(66, 'Dragan', 'Popovski', '2002-01-04', 'Fruskogorska 90', 'Pekar'),
(77, 'Relja', 'Dragic', '2000-08-17', 'Takovska 34', 'Poslasticar'),
(88, 'Goran', 'Stankovic', '2000-06-08', 'Slavka Manojlovica 4', 'Tehnicar robotike'),
(99, 'Pera', 'Zderic', '2003-04-26', 'Kolasinska 3', 'Elektricar');

-- --------------------------------------------------------

--
-- Table structure for table `citalac`
--

CREATE TABLE `citalac` (
  `citalacid` int(11) NOT NULL,
  `matbr` decimal(50,0) DEFAULT NULL,
  `ime` varchar(50) DEFAULT NULL,
  `prezime` varchar(50) DEFAULT NULL,
  `adresa` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `citalac`
--

INSERT INTO `citalac` (`citalacid`, `matbr`, `ime`, `prezime`, `adresa`) VALUES
(454, '1233124324234', 'Fikret', 'Gija', 'Odepadodje 34'),
(455, '8324234232352', 'Deki', 'Bmw', 'Resiogazamin 34'),
(456, '775773323245', 'Sida', 'Preko', 'Kajmakcalan 55'),
(457, '104007123456', 'Zoran', 'Hujkic', 'Fruskogorska 90'),
(458, '104007123777', 'Relja', 'Popovski', 'Kolasinska 3'),
(459, '104007123908', 'Goran', 'Stankovic', 'Slavka Manojlovica 4'),
(460, '106007123345', 'Zika', 'Gajic', 'Takovska 34'),
(461, '10600712339', 'Pera', 'Zderic', 'Fruskogorska 90'),
(462, '104007123555', 'Aga', 'Agic', 'Slavka Manojlovica 4'),
(463, '104007123123', 'Demiri', 'Dzajic', 'Mihajla Pupina 24'),
(464, '1233124324234', 'Fikret2', 'Gija2', 'Odepadodje 34');

-- --------------------------------------------------------

--
-- Table structure for table `izdali`
--

CREATE TABLE `izdali` (
  `izdavacid` int(11) NOT NULL,
  `knjigaid` int(11) NOT NULL,
  `godina` year(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `izdali`
--

INSERT INTO `izdali` (`izdavacid`, `knjigaid`, `godina`) VALUES
(111, 3, 2004),
(222, 2, 2000),
(222, 6, 2006),
(222, 7, 2000),
(333, 1, 1999),
(333, 3, 2004),
(555, 2, 1990),
(666, 10, 1990),
(888, 6, 2000),
(999, 9, 2014);

-- --------------------------------------------------------

--
-- Table structure for table `izdavac`
--

CREATE TABLE `izdavac` (
  `izdavacid` int(11) NOT NULL,
  `nazivizdavaca` varchar(50) DEFAULT NULL,
  `adresa` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `izdavac`
--

INSERT INTO `izdavac` (`izdavacid`, `nazivizdavaca`, `adresa`) VALUES
(111, 'Bika', 'Odepadodje 34'),
(222, 'Kiba', 'Draze Mihajlovica 34'),
(333, 'Kole', 'Fikreta Burzuja 75'),
(444, 'Peki', 'Ustanicka 4'),
(555, 'Sole', 'Hajduk Veljkova 34'),
(666, 'Marko', 'Mihajla Pupina 24'),
(777, 'Uki', 'Golemska 34'),
(888, 'Adri', 'Fruskogorska 90'),
(999, 'Gagi', 'Poljoprivredska 5'),
(1000, 'Hujka', 'Smedervska 56');

-- --------------------------------------------------------

--
-- Table structure for table `knjiga`
--

CREATE TABLE `knjiga` (
  `knjigaid` int(11) NOT NULL,
  `UDK` varchar(50) DEFAULT NULL,
  `ISBN` varchar(50) DEFAULT NULL,
  `naziv` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `knjiga`
--

INSERT INTO `knjiga` (`knjigaid`, `UDK`, `ISBN`, `naziv`) VALUES
(1, 'gg', 'np', 'Mali princ'),
(2, 'g', 'npp', 'Ciganin hvali svoga konja'),
(3, 'ggg', 'nnp', 'Bela griva'),
(4, 'gggg', 'n1', 'Gori selo a baba se ceslja'),
(5, 'ggggg', 'n2', 'Mesecev putnik'),
(6, 'gggggg', 'n3', 'Pokondirana tikva'),
(7, 'ggggggg', 'n4', 'Era prestola'),
(8, 'gggggggg', 'n5', 'Grane proklete'),
(9, 'ggggggggg', 'n6', 'Pakao'),
(10, 'gggggggggg', 'n7', 'Asimetricna lobanja');

-- --------------------------------------------------------

--
-- Table structure for table `nacitanju`
--

CREATE TABLE `nacitanju` (
  `knjigaid` int(11) NOT NULL,
  `citalacid` int(11) NOT NULL,
  `datumuzimanja` date NOT NULL,
  `datumvracanja` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nacitanju`
--

INSERT INTO `nacitanju` (`knjigaid`, `citalacid`, `datumuzimanja`, `datumvracanja`) VALUES
(1, 454, '2001-09-23', '2001-10-19'),
(1, 457, '2021-06-10', '2021-07-16'),
(2, 456, '2012-09-20', NULL),
(3, 455, '2001-03-23', '2001-05-25'),
(3, 461, '2022-05-12', '2022-06-22'),
(4, 463, '2016-10-20', '2016-12-20'),
(7, 455, '2012-05-20', '2012-07-28'),
(8, 459, '2003-04-01', NULL),
(8, 462, '2003-05-16', '2003-06-21'),
(10, 456, '2022-02-12', '2022-04-18');

-- --------------------------------------------------------

--
-- Table structure for table `napisali`
--

CREATE TABLE `napisali` (
  `autorid` int(11) NOT NULL,
  `knjigaid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `napisali`
--

INSERT INTO `napisali` (`autorid`, `knjigaid`) VALUES
(11, 2),
(22, 3),
(22, 6),
(33, 1),
(33, 2),
(33, 10),
(55, 1),
(55, 7),
(66, 5),
(100, 4);

-- --------------------------------------------------------

--
-- Table structure for table `primerak`
--

CREATE TABLE `primerak` (
  `knjigaid` int(11) NOT NULL,
  `primerakid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `primerak`
--

INSERT INTO `primerak` (`knjigaid`, `primerakid`) VALUES
(2, 36),
(2, 37),
(3, 38),
(3, 39),
(3, 45),
(4, 44),
(6, 40),
(8, 43),
(9, 41),
(9, 42);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `autor`
--
ALTER TABLE `autor`
  ADD PRIMARY KEY (`autorid`);

--
-- Indexes for table `citalac`
--
ALTER TABLE `citalac`
  ADD PRIMARY KEY (`citalacid`);

--
-- Indexes for table `izdali`
--
ALTER TABLE `izdali`
  ADD PRIMARY KEY (`izdavacid`,`knjigaid`),
  ADD KEY `knjigaid` (`knjigaid`);

--
-- Indexes for table `izdavac`
--
ALTER TABLE `izdavac`
  ADD PRIMARY KEY (`izdavacid`);

--
-- Indexes for table `knjiga`
--
ALTER TABLE `knjiga`
  ADD PRIMARY KEY (`knjigaid`);

--
-- Indexes for table `nacitanju`
--
ALTER TABLE `nacitanju`
  ADD PRIMARY KEY (`knjigaid`,`citalacid`,`datumuzimanja`),
  ADD KEY `citalacid` (`citalacid`);

--
-- Indexes for table `napisali`
--
ALTER TABLE `napisali`
  ADD KEY `knjigaid` (`knjigaid`);

--
-- Indexes for table `primerak`
--
ALTER TABLE `primerak`
  ADD PRIMARY KEY (`knjigaid`,`primerakid`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `izdali`
--
ALTER TABLE `izdali`
  ADD CONSTRAINT `izdali_ibfk_1` FOREIGN KEY (`izdavacid`) REFERENCES `izdavac` (`izdavacid`),
  ADD CONSTRAINT `izdali_ibfk_2` FOREIGN KEY (`knjigaid`) REFERENCES `knjiga` (`knjigaid`),
  ADD CONSTRAINT `izdali_ibfk_3` FOREIGN KEY (`izdavacid`) REFERENCES `izdavac` (`izdavacid`);

--
-- Constraints for table `nacitanju`
--
ALTER TABLE `nacitanju`
  ADD CONSTRAINT `nacitanju_ibfk_1` FOREIGN KEY (`knjigaid`) REFERENCES `knjiga` (`knjigaid`),
  ADD CONSTRAINT `nacitanju_ibfk_2` FOREIGN KEY (`citalacid`) REFERENCES `citalac` (`citalacid`),
  ADD CONSTRAINT `nacitanju_ibfk_3` FOREIGN KEY (`knjigaid`) REFERENCES `knjiga` (`knjigaid`);

--
-- Constraints for table `napisali`
--
ALTER TABLE `napisali`
  ADD CONSTRAINT `napisali_ibfk_1` FOREIGN KEY (`autorid`) REFERENCES `autor` (`autorid`),
  ADD CONSTRAINT `napisali_ibfk_2` FOREIGN KEY (`knjigaid`) REFERENCES `knjiga` (`knjigaid`),
  ADD CONSTRAINT `napisali_ibfk_3` FOREIGN KEY (`autorid`) REFERENCES `autor` (`autorid`);

--
-- Constraints for table `primerak`
--
ALTER TABLE `primerak`
  ADD CONSTRAINT `primerak_ibfk_1` FOREIGN KEY (`knjigaid`) REFERENCES `knjiga` (`knjigaid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
